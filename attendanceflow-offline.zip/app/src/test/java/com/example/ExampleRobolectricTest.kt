package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Employee Attendance Manager", appName)
  }

  @Test
  fun `verify password hashing and verification`() {
    val pin = "1234"
    val hash = com.example.data.security.SecurityHelper.hashPassword(pin)
    org.junit.Assert.assertTrue(com.example.data.security.SecurityHelper.verifyPassword(pin, hash))
    org.junit.Assert.assertFalse(com.example.data.security.SecurityHelper.verifyPassword("wrong", hash))
  }
}
