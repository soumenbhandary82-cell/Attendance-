package com.example.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.dao.AttendanceDao
import com.example.data.dao.AuditLogDao
import com.example.data.dao.CompanySettingsDao
import com.example.data.dao.EmployeeDao
import com.example.data.dao.HolidayDao
import com.example.data.dao.OvertimeDao
import com.example.data.dao.ShiftDao
import com.example.data.dao.UserDao
import com.example.data.model.AppUser
import com.example.data.model.AttendanceRecord
import com.example.data.model.AuditLog
import com.example.data.model.CompanySettings
import com.example.data.model.Employee
import com.example.data.model.Holiday
import com.example.data.model.OvertimeRecord
import com.example.data.model.Shift
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        AppUser::class,
        Employee::class,
        Shift::class,
        AttendanceRecord::class,
        OvertimeRecord::class,
        Holiday::class,
        AuditLog::class,
        CompanySettings::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun employeeDao(): EmployeeDao
    abstract fun shiftDao(): ShiftDao
    abstract fun attendanceDao(): AttendanceDao
    abstract fun overtimeDao(): OvertimeDao
    abstract fun holidayDao(): HolidayDao
    abstract fun auditLogDao(): AuditLogDao
    abstract fun companySettingsDao(): CompanySettingsDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "employee_attendance.db"
                ).addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        // Seed initial shifts & default company settings
                        CoroutineScope(Dispatchers.IO).launch {
                            val database = getInstance(context)
                            seedDefaults(database)
                        }
                    }
                }).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }

        private suspend fun seedDefaults(db: AppDatabase) {
            // Seed default shifts
            db.shiftDao().insertShifts(
                listOf(
                    Shift(id = 1, name = "A Shift", startTime = "06:00", endTime = "14:00", breakMinutes = 30, description = "Morning Shift"),
                    Shift(id = 2, name = "B Shift", startTime = "14:00", endTime = "22:00", breakMinutes = 30, description = "Evening Shift"),
                    Shift(id = 3, name = "C Shift", startTime = "22:00", endTime = "06:00", breakMinutes = 30, description = "Night Shift"),
                    Shift(id = 4, name = "Week Off", startTime = "00:00", endTime = "00:00", breakMinutes = 0, description = "Weekly Rest Day")
                )
            )
            // Seed company settings
            db.companySettingsDao().saveSettings(
                CompanySettings(
                    companyName = "Enterprise Workplace",
                    address = "100 Business Park Avenue",
                    contactEmail = "admin@workplace.local",
                    contactPhone = "+1 800 555 0199",
                    standardHoursPerDay = 8.0,
                    workingDaysPerWeek = 6,
                    defaultWeekOffDay = "Sunday",
                    defaultShiftName = "A Shift",
                    requireOtApproval = true
                )
            )
        }
    }
}
