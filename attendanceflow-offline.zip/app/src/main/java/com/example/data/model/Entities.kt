package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "users",
    indices = [Index(value = ["username"], unique = true)]
)
data class AppUser(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val username: String, // Owner ID or Admin ID
    val passwordHash: String,
    val salt: String,
    val role: UserRole,
    val displayName: String,
    val employeeId: String? = null,
    val canApproveOt: Boolean = true,
    val canManageHolidays: Boolean = true,
    val canExportReports: Boolean = true,
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "employees",
    indices = [
        Index(value = ["employeeId"], unique = true),
        Index(value = ["department"]),
        Index(value = ["name"])
    ]
)
data class Employee(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val employeeId: String, // Unique ID e.g. EMP001
    val name: String,
    val pinHash: String, // PIN for employee self-service login
    val salt: String,
    val mobileNumber: String = "",
    val department: String = "General",
    val designation: String = "Staff",
    val joiningDate: String = "", // YYYY-MM-DD
    val defaultShiftId: Long = 1,
    val defaultShiftName: String = "A Shift",
    val isActive: Boolean = true,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "shifts")
data class Shift(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String, // e.g. "A Shift", "B Shift", "C Shift", "Week Off"
    val startTime: String, // "06:00"
    val endTime: String, // "14:00"
    val breakMinutes: Int = 30,
    val description: String = "",
    val isActive: Boolean = true
)

@Entity(
    tableName = "attendance",
    indices = [
        Index(value = ["employeeId", "date"], unique = true),
        Index(value = ["date"]),
        Index(value = ["employeeId"]),
        Index(value = ["status"])
    ]
)
data class AttendanceRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val employeeId: String,
    val employeeName: String = "",
    val department: String = "",
    val date: String, // YYYY-MM-DD
    val shiftId: Long = 1,
    val shiftName: String = "A Shift",
    val status: AttendanceStatus = AttendanceStatus.PRESENT,
    val checkInTime: String = "", // HH:mm
    val checkOutTime: String = "", // HH:mm
    val overtimeHours: Double = 0.0,
    val remarks: String = "",
    val createdBy: String = "Admin",
    val lastModifiedBy: String = "Admin",
    val lastModifiedTimestamp: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "overtime",
    indices = [
        Index(value = ["employeeId"]),
        Index(value = ["date"]),
        Index(value = ["status"])
    ]
)
data class OvertimeRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val employeeId: String,
    val employeeName: String,
    val date: String, // YYYY-MM-DD
    val shiftName: String = "",
    val startTime: String = "", // HH:mm
    val endTime: String = "", // HH:mm
    val hours: Double = 0.0,
    val reason: String = "",
    val status: OvertimeStatus = OvertimeStatus.PENDING,
    val approvedBy: String = "",
    val remarks: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "holidays",
    indices = [Index(value = ["date"], unique = true)]
)
data class Holiday(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val date: String, // YYYY-MM-DD
    val description: String = ""
)

@Entity(
    tableName = "audit_logs",
    indices = [Index(value = ["timestamp"])]
)
data class AuditLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val userId: String,
    val userName: String,
    val role: String,
    val action: String,
    val details: String
)

@Entity(tableName = "company_settings")
data class CompanySettings(
    @PrimaryKey val id: Long = 1,
    val companyName: String = "Company Attendance",
    val address: String = "Corporate Office",
    val contactEmail: String = "contact@company.local",
    val contactPhone: String = "",
    val standardHoursPerDay: Double = 8.0,
    val workingDaysPerWeek: Int = 6,
    val defaultWeekOffDay: String = "Sunday", // Sunday, Saturday, etc.
    val defaultShiftName: String = "A Shift",
    val requireOtApproval: Boolean = true
)
