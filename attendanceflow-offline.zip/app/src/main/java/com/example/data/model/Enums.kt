package com.example.data.model

enum class UserRole {
    OWNER,
    ADMIN,
    EMPLOYEE
}

enum class AttendanceStatus(val displayName: String, val shortCode: String) {
    PRESENT("Present", "P"),
    ABSENT("Absent", "A"),
    LEAVE("Leave", "L"),
    HALF_DAY("Half Day", "HD"),
    WEEK_OFF("Week Off", "WO"),
    HOLIDAY("Holiday", "H")
}

enum class OvertimeStatus {
    PENDING,
    APPROVED,
    REJECTED
}
