package com.example.data.repository

import com.example.data.database.AppDatabase
import com.example.data.model.AppUser
import com.example.data.model.AttendanceRecord
import com.example.data.model.AuditLog
import com.example.data.model.CompanySettings
import com.example.data.model.Employee
import com.example.data.model.Holiday
import com.example.data.model.OvertimeRecord
import com.example.data.model.OvertimeStatus
import com.example.data.model.Shift
import com.example.data.model.UserRole
import kotlinx.coroutines.flow.Flow

class AttendanceRepository(private val database: AppDatabase) {
    private val userDao = database.userDao()
    private val employeeDao = database.employeeDao()
    private val shiftDao = database.shiftDao()
    private val attendanceDao = database.attendanceDao()
    private val overtimeDao = database.overtimeDao()
    private val holidayDao = database.holidayDao()
    private val auditLogDao = database.auditLogDao()
    private val settingsDao = database.companySettingsDao()

    // Users & Auth
    val ownerFlow: Flow<AppUser?> = userDao.getOwnerFlow()
    val allAdmins: Flow<List<AppUser>> = userDao.getAllAdmins()
    suspend fun getOwner(): AppUser? = userDao.getOwner()
    suspend fun getUserByUsername(username: String): AppUser? = userDao.getUserByUsername(username)
    suspend fun insertUser(user: AppUser): Long = userDao.insertUser(user)
    suspend fun updateUser(user: AppUser) = userDao.updateUser(user)
    suspend fun deleteUser(user: AppUser) = userDao.deleteUser(user)
    suspend fun countOwners(): Int = userDao.countOwners()

    // Employees
    val allEmployees: Flow<List<Employee>> = employeeDao.getAllEmployees()
    val activeEmployees: Flow<List<Employee>> = employeeDao.getActiveEmployees()
    val distinctDepartments: Flow<List<String>> = employeeDao.getDistinctDepartments()

    suspend fun getEmployeeByEmployeeId(empId: String): Employee? = employeeDao.getEmployeeByEmployeeId(empId)
    fun getEmployeeFlow(empId: String): Flow<Employee?> = employeeDao.getEmployeeByEmployeeIdFlow(empId)
    fun searchEmployees(query: String): Flow<List<Employee>> = employeeDao.searchEmployees(query)
    suspend fun insertEmployee(employee: Employee): Long = employeeDao.insertEmployee(employee)
    suspend fun insertEmployees(employees: List<Employee>) = employeeDao.insertEmployees(employees)
    suspend fun updateEmployee(employee: Employee) = employeeDao.updateEmployee(employee)
    suspend fun deleteEmployee(employee: Employee) = employeeDao.deleteEmployee(employee)
    suspend fun countTotalEmployees(): Int = employeeDao.countTotalEmployees()
    suspend fun countActiveEmployees(): Int = employeeDao.countActiveEmployees()

    // Shifts
    val allShifts: Flow<List<Shift>> = shiftDao.getAllShifts()
    val activeShifts: Flow<List<Shift>> = shiftDao.getActiveShifts()
    suspend fun getShiftById(id: Long): Shift? = shiftDao.getShiftById(id)
    suspend fun insertShift(shift: Shift): Long = shiftDao.insertShift(shift)
    suspend fun updateShift(shift: Shift) = shiftDao.updateShift(shift)
    suspend fun deleteShift(shift: Shift) = shiftDao.deleteShift(shift)

    // Attendance
    fun getAttendanceForDate(date: String): Flow<List<AttendanceRecord>> = attendanceDao.getAttendanceForDate(date)
    suspend fun getAttendanceForDateSync(date: String): List<AttendanceRecord> = attendanceDao.getAttendanceForDateSync(date)
    fun getAttendanceForEmployee(empId: String): Flow<List<AttendanceRecord>> = attendanceDao.getAttendanceForEmployee(empId)
    fun getAttendanceForEmployeeInMonth(empId: String, monthPrefix: String): Flow<List<AttendanceRecord>> =
        attendanceDao.getAttendanceForEmployeeInMonth(empId, monthPrefix)
    fun getAttendanceForDateRange(start: String, end: String): Flow<List<AttendanceRecord>> =
        attendanceDao.getAttendanceForDateRange(start, end)
    suspend fun getAttendanceForDateRangeSync(start: String, end: String): List<AttendanceRecord> =
        attendanceDao.getAttendanceForDateRangeSync(start, end)
    fun getAttendanceForMonth(monthPrefix: String): Flow<List<AttendanceRecord>> =
        attendanceDao.getAttendanceForMonth(monthPrefix)
    suspend fun getAttendanceForMonthSync(monthPrefix: String): List<AttendanceRecord> =
        attendanceDao.getAttendanceForMonthSync(monthPrefix)
    suspend fun saveAttendanceRecord(record: AttendanceRecord): Long = attendanceDao.insertOrUpdate(record)
    suspend fun saveAllAttendance(records: List<AttendanceRecord>) = attendanceDao.insertOrUpdateAll(records)
    suspend fun deleteAttendance(record: AttendanceRecord) = attendanceDao.delete(record)

    // Overtime
    val allOvertime: Flow<List<OvertimeRecord>> = overtimeDao.getAllOvertime()
    val pendingOvertime: Flow<List<OvertimeRecord>> = overtimeDao.getPendingOvertime()
    fun getOvertimeForEmployee(empId: String): Flow<List<OvertimeRecord>> = overtimeDao.getOvertimeForEmployee(empId)
    fun getApprovedOtForEmployeeInMonth(empId: String, monthPrefix: String): Flow<List<OvertimeRecord>> =
        overtimeDao.getApprovedOtForEmployeeInMonth(empId, monthPrefix)
    fun getApprovedOtHoursForEmployeeInMonth(empId: String, monthPrefix: String): Flow<Double?> =
        overtimeDao.getApprovedOtHoursForEmployeeInMonth(empId, monthPrefix)
    fun getTotalApprovedOtHoursInMonth(monthPrefix: String): Flow<Double?> =
        overtimeDao.getTotalApprovedOtHoursInMonth(monthPrefix)
    suspend fun insertOvertime(record: OvertimeRecord): Long = overtimeDao.insertOvertime(record)
    suspend fun updateOvertime(record: OvertimeRecord) = overtimeDao.updateOvertime(record)
    suspend fun deleteOvertime(record: OvertimeRecord) = overtimeDao.deleteOvertime(record)

    // Holidays
    val allHolidays: Flow<List<Holiday>> = holidayDao.getAllHolidays()
    suspend fun getHolidayByDate(date: String): Holiday? = holidayDao.getHolidayByDate(date)
    fun getHolidaysForMonth(monthPrefix: String): Flow<List<Holiday>> = holidayDao.getHolidaysForMonth(monthPrefix)
    suspend fun insertHoliday(holiday: Holiday): Long = holidayDao.insertHoliday(holiday)
    suspend fun updateHoliday(holiday: Holiday) = holidayDao.updateHoliday(holiday)
    suspend fun deleteHoliday(holiday: Holiday) = holidayDao.deleteHoliday(holiday)

    // Audit Logs
    val recentAuditLogs: Flow<List<AuditLog>> = auditLogDao.getRecentLogs()
    suspend fun logAction(userId: String, userName: String, role: String, action: String, details: String) {
        auditLogDao.insertLog(
            AuditLog(
                userId = userId,
                userName = userName,
                role = role,
                action = action,
                details = details
            )
        )
    }

    // Company Settings
    val settingsFlow: Flow<CompanySettings?> = settingsDao.getSettingsFlow()
    suspend fun getSettings(): CompanySettings = settingsDao.getSettings() ?: CompanySettings()
    suspend fun saveSettings(settings: CompanySettings) = settingsDao.saveSettings(settings)

    // Raw sync queries for Full Database Backup / Export
    suspend fun getAllUsersSync() = userDao.getAllUsersSync()
    suspend fun getAllEmployeesSync() = employeeDao.getAllEmployeesSync()
    suspend fun getAllShiftsSync() = shiftDao.getAllShiftsSync()
    suspend fun getAllAttendanceSync() = attendanceDao.getAllAttendanceSync()
    suspend fun getAllOvertimeSync() = overtimeDao.getAllOvertimeSync()
    suspend fun getAllHolidaysSync() = holidayDao.getAllHolidaysSync()
    suspend fun getAllLogsSync() = auditLogDao.getAllLogsSync()

    // Bulk Restore
    suspend fun restoreDatabase(
        users: List<AppUser>,
        employees: List<Employee>,
        shifts: List<Shift>,
        attendance: List<AttendanceRecord>,
        overtime: List<OvertimeRecord>,
        holidays: List<Holiday>,
        settings: CompanySettings?
    ) {
        if (users.isNotEmpty()) {
            for (user in users) {
                try { userDao.insertUser(user) } catch (e: Exception) { userDao.updateUser(user) }
            }
        }
        if (employees.isNotEmpty()) employeeDao.insertEmployees(employees)
        if (shifts.isNotEmpty()) shiftDao.insertShifts(shifts)
        if (attendance.isNotEmpty()) attendanceDao.insertOrUpdateAll(attendance)
        if (overtime.isNotEmpty()) overtimeDao.insertAll(overtime)
        if (holidays.isNotEmpty()) holidayDao.insertHolidays(holidays)
        if (settings != null) settingsDao.saveSettings(settings)
    }
}
