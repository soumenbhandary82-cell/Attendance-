package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.AppUser
import com.example.data.model.AttendanceRecord
import com.example.data.model.AuditLog
import com.example.data.model.CompanySettings
import com.example.data.model.Employee
import com.example.data.model.Holiday
import com.example.data.model.OvertimeRecord
import com.example.data.model.OvertimeStatus
import com.example.data.model.Shift
import com.example.data.model.UserRole
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Query("SELECT * FROM users WHERE role = 'OWNER' LIMIT 1")
    fun getOwnerFlow(): Flow<AppUser?>

    @Query("SELECT * FROM users WHERE role = 'OWNER' LIMIT 1")
    suspend fun getOwner(): AppUser?

    @Query("SELECT * FROM users WHERE username = :username LIMIT 1")
    suspend fun getUserByUsername(username: String): AppUser?

    @Query("SELECT * FROM users WHERE role = 'ADMIN' ORDER BY createdAt DESC")
    fun getAllAdmins(): Flow<List<AppUser>>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertUser(user: AppUser): Long

    @Update
    suspend fun updateUser(user: AppUser)

    @Delete
    suspend fun deleteUser(user: AppUser)

    @Query("SELECT COUNT(*) FROM users WHERE role = 'OWNER'")
    suspend fun countOwners(): Int

    @Query("SELECT * FROM users")
    suspend fun getAllUsersSync(): List<AppUser>
}

@Dao
interface EmployeeDao {
    @Query("SELECT * FROM employees ORDER BY name ASC")
    fun getAllEmployees(): Flow<List<Employee>>

    @Query("SELECT * FROM employees WHERE isActive = 1 ORDER BY name ASC")
    fun getActiveEmployees(): Flow<List<Employee>>

    @Query("SELECT * FROM employees WHERE employeeId = :employeeId LIMIT 1")
    suspend fun getEmployeeByEmployeeId(employeeId: String): Employee?

    @Query("SELECT * FROM employees WHERE employeeId = :employeeId LIMIT 1")
    fun getEmployeeByEmployeeIdFlow(employeeId: String): Flow<Employee?>

    @Query("""
        SELECT * FROM employees 
        WHERE employeeId LIKE '%' || :query || '%' 
           OR name LIKE '%' || :query || '%' 
           OR department LIKE '%' || :query || '%' 
           OR designation LIKE '%' || :query || '%'
        ORDER BY name ASC
    """)
    fun searchEmployees(query: String): Flow<List<Employee>>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertEmployee(employee: Employee): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEmployees(employees: List<Employee>)

    @Update
    suspend fun updateEmployee(employee: Employee)

    @Delete
    suspend fun deleteEmployee(employee: Employee)

    @Query("SELECT COUNT(*) FROM employees")
    suspend fun countTotalEmployees(): Int

    @Query("SELECT COUNT(*) FROM employees WHERE isActive = 1")
    suspend fun countActiveEmployees(): Int

    @Query("SELECT DISTINCT department FROM employees WHERE department != '' ORDER BY department ASC")
    fun getDistinctDepartments(): Flow<List<String>>

    @Query("SELECT * FROM employees")
    suspend fun getAllEmployeesSync(): List<Employee>
}

@Dao
interface ShiftDao {
    @Query("SELECT * FROM shifts ORDER BY id ASC")
    fun getAllShifts(): Flow<List<Shift>>

    @Query("SELECT * FROM shifts WHERE isActive = 1 ORDER BY id ASC")
    fun getActiveShifts(): Flow<List<Shift>>

    @Query("SELECT * FROM shifts WHERE id = :id LIMIT 1")
    suspend fun getShiftById(id: Long): Shift?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertShift(shift: Shift): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertShifts(shifts: List<Shift>)

    @Update
    suspend fun updateShift(shift: Shift)

    @Delete
    suspend fun deleteShift(shift: Shift)

    @Query("SELECT * FROM shifts")
    suspend fun getAllShiftsSync(): List<Shift>
}

@Dao
interface AttendanceDao {
    @Query("SELECT * FROM attendance WHERE date = :date ORDER BY employeeName ASC")
    fun getAttendanceForDate(date: String): Flow<List<AttendanceRecord>>

    @Query("SELECT * FROM attendance WHERE date = :date")
    suspend fun getAttendanceForDateSync(date: String): List<AttendanceRecord>

    @Query("SELECT * FROM attendance WHERE employeeId = :employeeId AND date = :date LIMIT 1")
    suspend fun getAttendanceForEmployeeAndDate(employeeId: String, date: String): AttendanceRecord?

    @Query("SELECT * FROM attendance WHERE employeeId = :employeeId ORDER BY date DESC")
    fun getAttendanceForEmployee(employeeId: String): Flow<List<AttendanceRecord>>

    @Query("SELECT * FROM attendance WHERE employeeId = :employeeId AND date LIKE :monthPrefix || '%' ORDER BY date ASC")
    fun getAttendanceForEmployeeInMonth(employeeId: String, monthPrefix: String): Flow<List<AttendanceRecord>>

    @Query("SELECT * FROM attendance WHERE date >= :startDate AND date <= :endDate ORDER BY date ASC, employeeName ASC")
    fun getAttendanceForDateRange(startDate: String, endDate: String): Flow<List<AttendanceRecord>>

    @Query("SELECT * FROM attendance WHERE date >= :startDate AND date <= :endDate ORDER BY date ASC, employeeName ASC")
    suspend fun getAttendanceForDateRangeSync(startDate: String, endDate: String): List<AttendanceRecord>

    @Query("SELECT * FROM attendance WHERE date LIKE :monthPrefix || '%' ORDER BY date ASC")
    fun getAttendanceForMonth(monthPrefix: String): Flow<List<AttendanceRecord>>

    @Query("SELECT * FROM attendance WHERE date LIKE :monthPrefix || '%'")
    suspend fun getAttendanceForMonthSync(monthPrefix: String): List<AttendanceRecord>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(record: AttendanceRecord): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateAll(records: List<AttendanceRecord>)

    @Delete
    suspend fun delete(record: AttendanceRecord)

    @Query("DELETE FROM attendance WHERE date = :date")
    suspend fun deleteForDate(date: String)

    @Query("SELECT * FROM attendance")
    suspend fun getAllAttendanceSync(): List<AttendanceRecord>
}

@Dao
interface OvertimeDao {
    @Query("SELECT * FROM overtime ORDER BY date DESC, createdAt DESC")
    fun getAllOvertime(): Flow<List<OvertimeRecord>>

    @Query("SELECT * FROM overtime WHERE status = 'PENDING' ORDER BY date DESC")
    fun getPendingOvertime(): Flow<List<OvertimeRecord>>

    @Query("SELECT * FROM overtime WHERE employeeId = :employeeId ORDER BY date DESC")
    fun getOvertimeForEmployee(employeeId: String): Flow<List<OvertimeRecord>>

    @Query("SELECT * FROM overtime WHERE employeeId = :employeeId AND status = 'APPROVED' AND date LIKE :monthPrefix || '%'")
    fun getApprovedOtForEmployeeInMonth(employeeId: String, monthPrefix: String): Flow<List<OvertimeRecord>>

    @Query("SELECT SUM(hours) FROM overtime WHERE employeeId = :employeeId AND status = 'APPROVED' AND date LIKE :monthPrefix || '%'")
    fun getApprovedOtHoursForEmployeeInMonth(employeeId: String, monthPrefix: String): Flow<Double?>

    @Query("SELECT SUM(hours) FROM overtime WHERE status = 'APPROVED' AND date LIKE :monthPrefix || '%'")
    fun getTotalApprovedOtHoursInMonth(monthPrefix: String): Flow<Double?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOvertime(record: OvertimeRecord): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(records: List<OvertimeRecord>)

    @Update
    suspend fun updateOvertime(record: OvertimeRecord)

    @Delete
    suspend fun deleteOvertime(record: OvertimeRecord)

    @Query("SELECT * FROM overtime")
    suspend fun getAllOvertimeSync(): List<OvertimeRecord>
}

@Dao
interface HolidayDao {
    @Query("SELECT * FROM holidays ORDER BY date ASC")
    fun getAllHolidays(): Flow<List<Holiday>>

    @Query("SELECT * FROM holidays WHERE date = :date LIMIT 1")
    suspend fun getHolidayByDate(date: String): Holiday?

    @Query("SELECT * FROM holidays WHERE date LIKE :monthPrefix || '%' ORDER BY date ASC")
    fun getHolidaysForMonth(monthPrefix: String): Flow<List<Holiday>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHoliday(holiday: Holiday): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHolidays(holidays: List<Holiday>)

    @Update
    suspend fun updateHoliday(holiday: Holiday)

    @Delete
    suspend fun deleteHoliday(holiday: Holiday)

    @Query("SELECT * FROM holidays")
    suspend fun getAllHolidaysSync(): List<Holiday>
}

@Dao
interface AuditLogDao {
    @Query("SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT 200")
    fun getRecentLogs(): Flow<List<AuditLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: AuditLog): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLogs(logs: List<AuditLog>)

    @Query("DELETE FROM audit_logs")
    suspend fun clearLogs()

    @Query("SELECT * FROM audit_logs")
    suspend fun getAllLogsSync(): List<AuditLog>
}

@Dao
interface CompanySettingsDao {
    @Query("SELECT * FROM company_settings WHERE id = 1 LIMIT 1")
    fun getSettingsFlow(): Flow<CompanySettings?>

    @Query("SELECT * FROM company_settings WHERE id = 1 LIMIT 1")
    suspend fun getSettings(): CompanySettings?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveSettings(settings: CompanySettings)
}
