package com.example.data.database

import androidx.room.TypeConverter
import com.example.data.model.AttendanceStatus
import com.example.data.model.OvertimeStatus
import com.example.data.model.UserRole

class Converters {
    @TypeConverter
    fun fromUserRole(role: UserRole?): String? = role?.name

    @TypeConverter
    fun toUserRole(value: String?): UserRole? = value?.let {
        try { UserRole.valueOf(it) } catch (e: Exception) { UserRole.ADMIN }
    }

    @TypeConverter
    fun fromAttendanceStatus(status: AttendanceStatus?): String? = status?.name

    @TypeConverter
    fun toAttendanceStatus(value: String?): AttendanceStatus? = value?.let {
        try { AttendanceStatus.valueOf(it) } catch (e: Exception) { AttendanceStatus.PRESENT }
    }

    @TypeConverter
    fun fromOvertimeStatus(status: OvertimeStatus?): String? = status?.name

    @TypeConverter
    fun toOvertimeStatus(value: String?): OvertimeStatus? = value?.let {
        try { OvertimeStatus.valueOf(it) } catch (e: Exception) { OvertimeStatus.PENDING }
    }
}
