package com.example.data.security

import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Locale

object SecurityHelper {
    private val secureRandom = SecureRandom()

    fun generateSalt(): String {
        val bytes = ByteArray(16)
        secureRandom.nextBytes(bytes)
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun hashPassword(password: String, salt: String): String {
        val input = "$salt:$password"
        val digest = MessageDigest.getInstance("SHA-256")
        val hashBytes = digest.digest(input.toByteArray(Charsets.UTF_8))
        return hashBytes.joinToString("") { "%02x".format(it) }
    }

    fun verifyPassword(password: String, salt: String, expectedHash: String): Boolean {
        val calculated = hashPassword(password, salt)
        return MessageDigest.isEqual(
            calculated.lowercase(Locale.ROOT).toByteArray(Charsets.UTF_8),
            expectedHash.lowercase(Locale.ROOT).toByteArray(Charsets.UTF_8)
        )
    }
}
