package com.example.util

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import com.example.data.model.AppUser
import com.example.data.model.AttendanceRecord
import com.example.data.model.AttendanceStatus
import com.example.data.model.CompanySettings
import com.example.data.model.Employee
import com.example.data.model.Holiday
import com.example.data.model.OvertimeRecord
import com.example.data.model.OvertimeStatus
import com.example.data.model.Shift
import com.example.data.model.UserRole
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class RestoreData(
    val users: List<AppUser>,
    val employees: List<Employee>,
    val shifts: List<Shift>,
    val attendance: List<AttendanceRecord>,
    val overtime: List<OvertimeRecord>,
    val holidays: List<Holiday>,
    val settings: CompanySettings?
)

object BackupHelper {

    fun createBackupJson(
        users: List<AppUser>,
        employees: List<Employee>,
        shifts: List<Shift>,
        attendance: List<AttendanceRecord>,
        overtime: List<OvertimeRecord>,
        holidays: List<Holiday>,
        settings: CompanySettings
    ): String {
        val root = JSONObject()
        root.put("app", "EmployeeAttendanceManager")
        root.put("version", 1)
        root.put("exportedAt", System.currentTimeMillis())

        // Users
        val usersArr = JSONArray()
        for (u in users) {
            val obj = JSONObject()
            obj.put("username", u.username)
            obj.put("passwordHash", u.passwordHash)
            obj.put("salt", u.salt)
            obj.put("role", u.role.name)
            obj.put("displayName", u.displayName)
            obj.put("employeeId", u.employeeId ?: "")
            obj.put("canApproveOt", u.canApproveOt)
            obj.put("canManageHolidays", u.canManageHolidays)
            obj.put("canExportReports", u.canExportReports)
            obj.put("isActive", u.isActive)
            usersArr.put(obj)
        }
        root.put("users", usersArr)

        // Employees
        val empArr = JSONArray()
        for (e in employees) {
            val obj = JSONObject()
            obj.put("employeeId", e.employeeId)
            obj.put("name", e.name)
            obj.put("pinHash", e.pinHash)
            obj.put("salt", e.salt)
            obj.put("mobileNumber", e.mobileNumber)
            obj.put("department", e.department)
            obj.put("designation", e.designation)
            obj.put("joiningDate", e.joiningDate)
            obj.put("defaultShiftName", e.defaultShiftName)
            obj.put("isActive", e.isActive)
            obj.put("notes", e.notes)
            empArr.put(obj)
        }
        root.put("employees", empArr)

        // Shifts
        val shiftArr = JSONArray()
        for (s in shifts) {
            val obj = JSONObject()
            obj.put("name", s.name)
            obj.put("startTime", s.startTime)
            obj.put("endTime", s.endTime)
            obj.put("breakMinutes", s.breakMinutes)
            obj.put("description", s.description)
            obj.put("isActive", s.isActive)
            shiftArr.put(obj)
        }
        root.put("shifts", shiftArr)

        // Attendance
        val attArr = JSONArray()
        for (a in attendance) {
            val obj = JSONObject()
            obj.put("employeeId", a.employeeId)
            obj.put("employeeName", a.employeeName)
            obj.put("department", a.department)
            obj.put("date", a.date)
            obj.put("shiftName", a.shiftName)
            obj.put("status", a.status.name)
            obj.put("checkInTime", a.checkInTime)
            obj.put("checkOutTime", a.checkOutTime)
            obj.put("overtimeHours", a.overtimeHours)
            obj.put("remarks", a.remarks)
            obj.put("createdBy", a.createdBy)
            attArr.put(obj)
        }
        root.put("attendance", attArr)

        // Overtime
        val otArr = JSONArray()
        for (o in overtime) {
            val obj = JSONObject()
            obj.put("employeeId", o.employeeId)
            obj.put("employeeName", o.employeeName)
            obj.put("date", o.date)
            obj.put("shiftName", o.shiftName)
            obj.put("hours", o.hours)
            obj.put("reason", o.reason)
            obj.put("status", o.status.name)
            obj.put("approvedBy", o.approvedBy)
            otArr.put(obj)
        }
        root.put("overtime", otArr)

        // Holidays
        val holArr = JSONArray()
        for (h in holidays) {
            val obj = JSONObject()
            obj.put("name", h.name)
            obj.put("date", h.date)
            obj.put("description", h.description)
            holArr.put(obj)
        }
        root.put("holidays", holArr)

        // Settings
        val setObj = JSONObject()
        setObj.put("companyName", settings.companyName)
        setObj.put("address", settings.address)
        setObj.put("contactEmail", settings.contactEmail)
        setObj.put("contactPhone", settings.contactPhone)
        setObj.put("standardHoursPerDay", settings.standardHoursPerDay)
        setObj.put("workingDaysPerWeek", settings.workingDaysPerWeek)
        setObj.put("defaultWeekOffDay", settings.defaultWeekOffDay)
        root.put("settings", setObj)

        return root.toString(2)
    }

    fun parseBackupJson(jsonString: String): RestoreData {
        val root = JSONObject(jsonString)
        if (!root.has("app") || root.getString("app") != "EmployeeAttendanceManager") {
            throw IllegalArgumentException("Invalid backup file: Not an Employee Attendance Manager backup.")
        }

        // Users
        val users = mutableListOf<AppUser>()
        if (root.has("users")) {
            val arr = root.getJSONArray("users")
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                users.add(
                    AppUser(
                        username = obj.getString("username"),
                        passwordHash = obj.getString("passwordHash"),
                        salt = obj.getString("salt"),
                        role = UserRole.valueOf(obj.getString("role")),
                        displayName = obj.optString("displayName", "User"),
                        employeeId = obj.optString("employeeId", null).ifBlank { null },
                        canApproveOt = obj.optBoolean("canApproveOt", true),
                        canManageHolidays = obj.optBoolean("canManageHolidays", true),
                        canExportReports = obj.optBoolean("canExportReports", true),
                        isActive = obj.optBoolean("isActive", true)
                    )
                )
            }
        }

        // Employees
        val employees = mutableListOf<Employee>()
        if (root.has("employees")) {
            val arr = root.getJSONArray("employees")
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                employees.add(
                    Employee(
                        employeeId = obj.getString("employeeId"),
                        name = obj.getString("name"),
                        pinHash = obj.getString("pinHash"),
                        salt = obj.getString("salt"),
                        mobileNumber = obj.optString("mobileNumber", ""),
                        department = obj.optString("department", "General"),
                        designation = obj.optString("designation", "Staff"),
                        joiningDate = obj.optString("joiningDate", ""),
                        defaultShiftName = obj.optString("defaultShiftName", "A Shift"),
                        isActive = obj.optBoolean("isActive", true),
                        notes = obj.optString("notes", "")
                    )
                )
            }
        }

        // Shifts
        val shifts = mutableListOf<Shift>()
        if (root.has("shifts")) {
            val arr = root.getJSONArray("shifts")
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                shifts.add(
                    Shift(
                        name = obj.getString("name"),
                        startTime = obj.optString("startTime", "08:00"),
                        endTime = obj.optString("endTime", "16:00"),
                        breakMinutes = obj.optInt("breakMinutes", 30),
                        description = obj.optString("description", ""),
                        isActive = obj.optBoolean("isActive", true)
                    )
                )
            }
        }

        // Attendance
        val attendance = mutableListOf<AttendanceRecord>()
        if (root.has("attendance")) {
            val arr = root.getJSONArray("attendance")
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                attendance.add(
                    AttendanceRecord(
                        employeeId = obj.getString("employeeId"),
                        employeeName = obj.optString("employeeName", ""),
                        department = obj.optString("department", ""),
                        date = obj.getString("date"),
                        shiftName = obj.optString("shiftName", "A Shift"),
                        status = AttendanceStatus.valueOf(obj.getString("status")),
                        checkInTime = obj.optString("checkInTime", ""),
                        checkOutTime = obj.optString("checkOutTime", ""),
                        overtimeHours = obj.optDouble("overtimeHours", 0.0),
                        remarks = obj.optString("remarks", ""),
                        createdBy = obj.optString("createdBy", "Admin")
                    )
                )
            }
        }

        // Overtime
        val overtime = mutableListOf<OvertimeRecord>()
        if (root.has("overtime")) {
            val arr = root.getJSONArray("overtime")
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                overtime.add(
                    OvertimeRecord(
                        employeeId = obj.getString("employeeId"),
                        employeeName = obj.optString("employeeName", ""),
                        date = obj.getString("date"),
                        shiftName = obj.optString("shiftName", ""),
                        hours = obj.optDouble("hours", 0.0),
                        reason = obj.optString("reason", ""),
                        status = OvertimeStatus.valueOf(obj.getString("status")),
                        approvedBy = obj.optString("approvedBy", "")
                    )
                )
            }
        }

        // Holidays
        val holidays = mutableListOf<Holiday>()
        if (root.has("holidays")) {
            val arr = root.getJSONArray("holidays")
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                holidays.add(
                    Holiday(
                        name = obj.getString("name"),
                        date = obj.getString("date"),
                        description = obj.optString("description", "")
                    )
                )
            }
        }

        // Settings
        var settings: CompanySettings? = null
        if (root.has("settings")) {
            val obj = root.getJSONObject("settings")
            settings = CompanySettings(
                companyName = obj.optString("companyName", "Workplace"),
                address = obj.optString("address", ""),
                contactEmail = obj.optString("contactEmail", ""),
                contactPhone = obj.optString("contactPhone", ""),
                standardHoursPerDay = obj.optDouble("standardHoursPerDay", 8.0),
                workingDaysPerWeek = obj.optInt("workingDaysPerWeek", 6),
                defaultWeekOffDay = obj.optString("defaultWeekOffDay", "Sunday")
            )
        }

        return RestoreData(
            users = users,
            employees = employees,
            shifts = shifts,
            attendance = attendance,
            overtime = overtime,
            holidays = holidays,
            settings = settings
        )
    }

    fun shareBackup(context: Context, jsonContent: String) {
        val exportDir = File(context.cacheDir, "exports")
        if (!exportDir.exists()) exportDir.mkdirs()
        val file = File(exportDir, "attendance_backup_${System.currentTimeMillis()}.json")
        file.writeText(jsonContent, Charsets.UTF_8)

        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/json"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "Attendance Database Backup")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Share Database Backup"))
    }
}
