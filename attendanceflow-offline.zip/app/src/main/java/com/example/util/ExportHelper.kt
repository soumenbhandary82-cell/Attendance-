package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import com.example.data.model.AttendanceRecord
import com.example.data.model.AttendanceStatus
import com.example.data.model.CompanySettings
import java.io.File
import java.io.FileOutputStream

object ExportHelper {

    fun generateCsv(
        records: List<AttendanceRecord>,
        companySettings: CompanySettings? = null
    ): String {
        val sb = StringBuilder()
        // UTF-8 BOM so Excel opens properly
        sb.append('\uFEFF')
        if (companySettings != null) {
            sb.append("# Company: ").append(escapeCsv(companySettings.companyName)).append("\n")
            sb.append("# Generated: ").append(DateUtils.getTodayDate()).append(" ").append(DateUtils.getCurrentTime()).append("\n")
        }
        sb.append("Date,Employee ID,Employee Name,Department,Shift,Attendance Status,Check In,Check Out,OT Hours,Remarks,Created By\n")
        for (r in records) {
            sb.append(escapeCsv(r.date)).append(",")
            sb.append(escapeCsv(r.employeeId)).append(",")
            sb.append(escapeCsv(r.employeeName)).append(",")
            sb.append(escapeCsv(r.department)).append(",")
            sb.append(escapeCsv(r.shiftName)).append(",")
            sb.append(escapeCsv(r.status.displayName)).append(",")
            sb.append(escapeCsv(r.checkInTime)).append(",")
            sb.append(escapeCsv(r.checkOutTime)).append(",")
            sb.append(r.overtimeHours).append(",")
            sb.append(escapeCsv(r.remarks)).append(",")
            sb.append(escapeCsv(r.createdBy)).append("\n")
        }
        return sb.toString()
    }

    private fun escapeCsv(value: String): String {
        var str = value.replace("\"", "\"\"")
        if (str.contains(",") || str.contains("\n") || str.contains("\"")) {
            str = "\"$str\""
        }
        return str
    }

    fun shareCsv(context: Context, csvContent: String, filename: String) {
        val exportDir = File(context.cacheDir, "exports")
        if (!exportDir.exists()) exportDir.mkdirs()
        val file = File(exportDir, "$filename.csv")
        file.writeText(csvContent, Charsets.UTF_8)

        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "Attendance Report - $filename")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Share Attendance CSV"))
    }

    fun generateAndSharePdf(
        context: Context,
        reportTitle: String,
        dateRange: String,
        records: List<AttendanceRecord>,
        companySettings: CompanySettings
    ) {
        val document = PdfDocument()
        val pageWidth = 595
        val pageHeight = 842
        val rowsPerPage = 22

        val titlePaint = Paint().apply {
            color = Color.rgb(30, 58, 138)
            textSize = 16f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        val subTitlePaint = Paint().apply {
            color = Color.DKGRAY
            textSize = 10f
            isAntiAlias = true
        }
        val headerPaint = Paint().apply {
            color = Color.rgb(30, 41, 59)
            textSize = 11f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        val textPaint = Paint().apply {
            color = Color.BLACK
            textSize = 9f
            isAntiAlias = true
        }
        val boldTextPaint = Paint().apply {
            color = Color.BLACK
            textSize = 9f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        val tableHeaderBgPaint = Paint().apply {
            color = Color.rgb(241, 245, 249)
            style = Paint.Style.FILL
        }
        val alternateRowBgPaint = Paint().apply {
            color = Color.rgb(248, 250, 252)
            style = Paint.Style.FILL
        }
        val borderPaint = Paint().apply {
            color = Color.rgb(203, 213, 225)
            strokeWidth = 1f
            style = Paint.Style.STROKE
        }

        val totalPages = if (records.isEmpty()) 1 else ((records.size + rowsPerPage - 1) / rowsPerPage)

        for (pageIndex in 0 until totalPages) {
            val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageIndex + 1).create()
            val page = document.startPage(pageInfo)
            val canvas = page.canvas

            var currentY = 40f

            // Draw Header on every page
            canvas.drawText(companySettings.companyName.uppercase(), 36f, currentY, titlePaint)
            currentY += 14f
            canvas.drawText("${companySettings.address} | Email: ${companySettings.contactEmail}", 36f, currentY, subTitlePaint)
            currentY += 14f
            canvas.drawText("REPORT: $reportTitle | DATE RANGE: $dateRange", 36f, currentY, headerPaint)
            currentY += 18f

            // Draw Summary Box on first page
            if (pageIndex == 0) {
                val presentCount = records.count { it.status == AttendanceStatus.PRESENT }
                val absentCount = records.count { it.status == AttendanceStatus.ABSENT }
                val leaveCount = records.count { it.status == AttendanceStatus.LEAVE }
                val halfDayCount = records.count { it.status == AttendanceStatus.HALF_DAY }
                val totalOt = records.sumOf { it.overtimeHours }

                canvas.drawRect(36f, currentY, (pageWidth - 36).toFloat(), currentY + 28f, tableHeaderBgPaint)
                canvas.drawRect(36f, currentY, (pageWidth - 36).toFloat(), currentY + 28f, borderPaint)

                val summaryText = "Total: ${records.size}  |  Present: $presentCount  |  Absent: $absentCount  |  Leave: $leaveCount  |  Half Day: $halfDayCount  |  OT Hours: %.1f".format(totalOt)
                canvas.drawText(summaryText, 44f, currentY + 18f, boldTextPaint)
                currentY += 38f
            }

            // Table Columns
            val colX = floatArrayOf(36f, 90f, 160f, 280f, 370f, 440f, 510f)
            val colHeaders = arrayOf("Date", "Emp ID", "Name", "Department", "Shift", "Status", "OT (h)")

            // Table Header Row
            val headerHeight = 22f
            canvas.drawRect(36f, currentY, (pageWidth - 36).toFloat(), currentY + headerHeight, tableHeaderBgPaint)
            canvas.drawRect(36f, currentY, (pageWidth - 36).toFloat(), currentY + headerHeight, borderPaint)

            for (i in colHeaders.indices) {
                canvas.drawText(colHeaders[i], colX[i] + 4f, currentY + 15f, boldTextPaint)
            }
            currentY += headerHeight

            // Table Rows
            val startIndex = pageIndex * rowsPerPage
            val endIndex = minOf(startIndex + rowsPerPage, records.size)
            val rowHeight = 20f

            for (i in startIndex until endIndex) {
                val record = records[i]
                if (i % 2 == 1) {
                    canvas.drawRect(36f, currentY, (pageWidth - 36).toFloat(), currentY + rowHeight, alternateRowBgPaint)
                }
                canvas.drawRect(36f, currentY, (pageWidth - 36).toFloat(), currentY + rowHeight, borderPaint)

                val shortDate = if (record.date.length >= 10) record.date.substring(5) else record.date
                canvas.drawText(shortDate, colX[0] + 4f, currentY + 14f, textPaint)
                canvas.drawText(record.employeeId, colX[1] + 4f, currentY + 14f, textPaint)
                val safeName = if (record.employeeName.length > 18) record.employeeName.substring(0, 16) + ".." else record.employeeName
                canvas.drawText(safeName, colX[2] + 4f, currentY + 14f, textPaint)
                val safeDept = if (record.department.length > 14) record.department.substring(0, 12) + ".." else record.department
                canvas.drawText(safeDept, colX[3] + 4f, currentY + 14f, textPaint)
                canvas.drawText(record.shiftName, colX[4] + 4f, currentY + 14f, textPaint)
                canvas.drawText(record.status.displayName, colX[5] + 4f, currentY + 14f, boldTextPaint)
                val otText = if (record.overtimeHours > 0) "%.1f".format(record.overtimeHours) else "-"
                canvas.drawText(otText, colX[6] + 4f, currentY + 14f, textPaint)

                currentY += rowHeight
            }

            // Footer
            val footerY = (pageHeight - 30).toFloat()
            canvas.drawText("Page ${pageIndex + 1} of $totalPages | Employee Attendance Manager", 36f, footerY, subTitlePaint)
            canvas.drawText("Generated offline on ${DateUtils.getTodayDate()}", (pageWidth - 200).toFloat(), footerY, subTitlePaint)

            document.finishPage(page)
        }

        val exportDir = File(context.cacheDir, "exports")
        if (!exportDir.exists()) exportDir.mkdirs()
        val pdfFile = File(exportDir, "Attendance_${System.currentTimeMillis()}.pdf")
        val fos = FileOutputStream(pdfFile)
        document.writeTo(fos)
        document.close()
        fos.flush()
        fos.close()

        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            pdfFile
        )

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "$reportTitle - $dateRange")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Share Attendance PDF"))
    }
}
