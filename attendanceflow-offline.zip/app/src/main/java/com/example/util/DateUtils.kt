package com.example.util

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object DateUtils {
    private val isoDateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    private val displayDateFormat = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
    private val monthFormat = SimpleDateFormat("yyyy-MM", Locale.getDefault())
    private val monthDisplayNameFormat = SimpleDateFormat("MMMM yyyy", Locale.getDefault())
    private val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())

    fun getTodayDate(): String = isoDateFormat.format(Date())

    fun getCurrentMonth(): String = monthFormat.format(Date())

    fun getCurrentTime(): String = timeFormat.format(Date())

    fun formatToDisplayDate(isoDate: String): String {
        return try {
            val d = isoDateFormat.parse(isoDate) ?: return isoDate
            displayDateFormat.format(d)
        } catch (e: Exception) {
            isoDate
        }
    }

    fun formatMonthDisplayName(monthPrefix: String): String {
        return try {
            val d = monthFormat.parse(monthPrefix) ?: return monthPrefix
            monthDisplayNameFormat.format(d)
        } catch (e: Exception) {
            monthPrefix
        }
    }

    fun getPreviousDate(isoDate: String): String {
        return try {
            val cal = Calendar.getInstance()
            cal.time = isoDateFormat.parse(isoDate) ?: Date()
            cal.add(Calendar.DAY_OF_YEAR, -1)
            isoDateFormat.format(cal.time)
        } catch (e: Exception) {
            isoDate
        }
    }

    fun getNextDate(isoDate: String): String {
        return try {
            val cal = Calendar.getInstance()
            cal.time = isoDateFormat.parse(isoDate) ?: Date()
            cal.add(Calendar.DAY_OF_YEAR, 1)
            isoDateFormat.format(cal.time)
        } catch (e: Exception) {
            isoDate
        }
    }

    fun getPreviousMonth(monthPrefix: String): String {
        return try {
            val cal = Calendar.getInstance()
            cal.time = monthFormat.parse(monthPrefix) ?: Date()
            cal.add(Calendar.MONTH, -1)
            monthFormat.format(cal.time)
        } catch (e: Exception) {
            monthPrefix
        }
    }

    fun getNextMonth(monthPrefix: String): String {
        return try {
            val cal = Calendar.getInstance()
            cal.time = monthFormat.parse(monthPrefix) ?: Date()
            cal.add(Calendar.MONTH, 1)
            monthFormat.format(cal.time)
        } catch (e: Exception) {
            monthPrefix
        }
    }

    fun getDaysInMonth(monthPrefix: String): List<String> {
        val days = mutableListOf<String>()
        try {
            val cal = Calendar.getInstance()
            cal.time = monthFormat.parse(monthPrefix) ?: Date()
            val maxDay = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
            val year = cal.get(Calendar.YEAR)
            val month = cal.get(Calendar.MONTH) + 1
            for (i in 1..maxDay) {
                days.add("%04d-%02d-%02d".format(year, month, i))
            }
        } catch (e: Exception) {
            // fallback
        }
        return days
    }

    fun getDayOfWeek(isoDate: String): String {
        return try {
            val cal = Calendar.getInstance()
            cal.time = isoDateFormat.parse(isoDate) ?: Date()
            val sdf = SimpleDateFormat("EEEE", Locale.getDefault())
            sdf.format(cal.time)
        } catch (e: Exception) {
            ""
        }
    }
}
