package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*
import com.example.data.model.UserRole
import com.example.data.repository.AttendanceRepository
import com.example.ui.screens.*
import com.example.ui.theme.AccentAmber
import com.example.ui.theme.PrimaryNavy
import com.example.ui.viewmodel.*

sealed class AppDestinations(val route: String, val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    object Dashboard : AppDestinations("dashboard", "Dashboard", Icons.Default.Dashboard)
    object DailyAttendance : AppDestinations("attendance", "Daily Attendance", Icons.Default.FactCheck)
    object Calendar : AppDestinations("calendar", "Calendar", Icons.Default.CalendarMonth)
    object Employees : AppDestinations("employees", "Employees", Icons.Default.People)
    object Reports : AppDestinations("reports", "Reports", Icons.Default.Assessment)
    object Shifts : AppDestinations("shifts", "Shifts", Icons.Default.Schedule)
    object Overtime : AppDestinations("overtime", "Overtime", Icons.Default.Timer)
    object Holidays : AppDestinations("holidays", "Holidays", Icons.Default.Event)
    object Settings : AppDestinations("settings", "Settings", Icons.Default.Settings)
}

val BottomNavDestinations = listOf(
    AppDestinations.Dashboard,
    AppDestinations.DailyAttendance,
    AppDestinations.Calendar,
    AppDestinations.Employees,
    AppDestinations.Reports
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainApp(
    repository: AttendanceRepository,
    modifier: Modifier = Modifier
) {
    val authViewModel: AuthViewModel = viewModel(factory = AuthViewModelFactory(repository))
    val authState by authViewModel.uiState.collectAsState()

    // Unauthenticated State
    if (!authState.isLoggedIn) {
        if (!authState.hasOwnerAccount) {
            SetupScreen(authViewModel = authViewModel)
        } else {
            LoginScreen(authViewModel = authViewModel)
        }
        return
    }

    val currentUser = authState.currentUser ?: return

    // Employee Portal (Strictly read-only self view)
    if (currentUser.role == UserRole.EMPLOYEE) {
        val employeeViewModel: EmployeeViewModel = viewModel(
            key = currentUser.username,
            factory = EmployeeViewModelFactory(repository, currentUser.username)
        )
        EmployeePortalScreen(
            employeeViewModel = employeeViewModel,
            onLogout = { authViewModel.logout() }
        )
        return
    }

    // Owner or Admin Experience
    val mainViewModel: MainViewModel = viewModel(
        factory = MainViewModelFactory(repository, currentUser)
    )

    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: AppDestinations.Dashboard.route
    val snackbarHostState = remember { SnackbarHostState() }

    val userMessage by mainViewModel.userMessage.collectAsState()
    LaunchedEffect(userMessage) {
        userMessage?.let {
            snackbarHostState.showSnackbar(it)
            mainViewModel.clearUserMessage()
        }
    }

    val metrics by mainViewModel.dashboardMetrics.collectAsState()
    var moreMenuExpanded by remember { mutableStateOf(false) }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    val currentTitle = when (currentRoute) {
                        AppDestinations.Dashboard.route -> "Attendance Manager"
                        AppDestinations.DailyAttendance.route -> "Daily Roll Call"
                        AppDestinations.Calendar.route -> "Workplace Calendar"
                        AppDestinations.Employees.route -> "Staff Directory"
                        AppDestinations.Reports.route -> "Attendance & OT Reports"
                        AppDestinations.Shifts.route -> "Shift Roster"
                        AppDestinations.Overtime.route -> "Overtime Management"
                        AppDestinations.Holidays.route -> "Holidays"
                        AppDestinations.Settings.route -> "Settings"
                        else -> "Attendance Manager"
                    }
                    Text(
                        text = currentTitle,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium
                    )
                },
                actions = {
                    // Overtime Shortcut with Badge
                    IconButton(
                        onClick = { navController.navigate(AppDestinations.Overtime.route) },
                        modifier = Modifier.testTag("top_ot_button")
                    ) {
                        BadgedBox(
                            badge = {
                                if (metrics.pendingOtCount > 0) {
                                    Badge(containerColor = AccentAmber) {
                                        Text("${metrics.pendingOtCount}")
                                    }
                                }
                            }
                        ) {
                            Icon(Icons.Default.Timer, contentDescription = "Overtime")
                        }
                    }

                    // More Menu
                    Box {
                        IconButton(
                            onClick = { moreMenuExpanded = true },
                            modifier = Modifier.testTag("top_more_menu_button")
                        ) {
                            Icon(Icons.Default.MoreVert, contentDescription = "More Options")
                        }

                        DropdownMenu(
                            expanded = moreMenuExpanded,
                            onDismissRequest = { moreMenuExpanded = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Shift Management") },
                                leadingIcon = { Icon(Icons.Default.Schedule, contentDescription = null) },
                                onClick = {
                                    navController.navigate(AppDestinations.Shifts.route)
                                    moreMenuExpanded = false
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Company Holidays") },
                                leadingIcon = { Icon(Icons.Default.Event, contentDescription = null) },
                                onClick = {
                                    navController.navigate(AppDestinations.Holidays.route)
                                    moreMenuExpanded = false
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Settings & Backup") },
                                leadingIcon = { Icon(Icons.Default.Settings, contentDescription = null) },
                                onClick = {
                                    navController.navigate(AppDestinations.Settings.route)
                                    moreMenuExpanded = false
                                }
                            )
                            Divider()
                            DropdownMenuItem(
                                text = { Text("Sign Out (${currentUser.displayName})") },
                                leadingIcon = { Icon(Icons.Default.Logout, contentDescription = null) },
                                onClick = {
                                    moreMenuExpanded = false
                                    authViewModel.logout()
                                }
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = PrimaryNavy,
                    titleContentColor = Color.White,
                    actionIconContentColor = Color.White
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp
            ) {
                BottomNavDestinations.forEach { screen ->
                    NavigationBarItem(
                        icon = { Icon(screen.icon, contentDescription = screen.title) },
                        label = { Text(screen.title) },
                        selected = currentRoute == screen.route,
                        modifier = Modifier.testTag("nav_item_${screen.route}"),
                        onClick = {
                            if (currentRoute != screen.route) {
                                navController.navigate(screen.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = AppDestinations.Dashboard.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(AppDestinations.Dashboard.route) {
                OwnerAdminDashboardScreen(
                    mainViewModel = mainViewModel,
                    currentUser = currentUser,
                    onNavigateToAttendance = { navController.navigate(AppDestinations.DailyAttendance.route) },
                    onNavigateToEmployees = { navController.navigate(AppDestinations.Employees.route) },
                    onNavigateToReports = { navController.navigate(AppDestinations.Reports.route) },
                    onNavigateToOvertime = { navController.navigate(AppDestinations.Overtime.route) }
                )
            }
            composable(AppDestinations.DailyAttendance.route) {
                DailyAttendanceScreen(mainViewModel = mainViewModel)
            }
            composable(AppDestinations.Calendar.route) {
                CalendarScreen(
                    mainViewModel = mainViewModel,
                    onNavigateToRollCall = {
                        navController.navigate(AppDestinations.DailyAttendance.route)
                    }
                )
            }
            composable(AppDestinations.Employees.route) {
                EmployeeManagementScreen(mainViewModel = mainViewModel)
            }
            composable(AppDestinations.Reports.route) {
                ReportsScreen(mainViewModel = mainViewModel)
            }
            composable(AppDestinations.Shifts.route) {
                ShiftManagementScreen(mainViewModel = mainViewModel)
            }
            composable(AppDestinations.Overtime.route) {
                OvertimeScreen(mainViewModel = mainViewModel)
            }
            composable(AppDestinations.Holidays.route) {
                HolidayScreen(mainViewModel = mainViewModel)
            }
            composable(AppDestinations.Settings.route) {
                SettingsScreen(mainViewModel = mainViewModel, currentUser = currentUser)
            }
        }
    }
}
