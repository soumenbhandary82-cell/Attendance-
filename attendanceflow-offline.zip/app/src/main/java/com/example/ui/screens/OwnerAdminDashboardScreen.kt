package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UserRole
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.UserSession
import com.example.util.DateUtils

@Composable
fun OwnerAdminDashboardScreen(
    mainViewModel: MainViewModel,
    currentUser: UserSession,
    onNavigateToAttendance: () -> Unit,
    onNavigateToEmployees: () -> Unit,
    onNavigateToReports: () -> Unit,
    onNavigateToOvertime: () -> Unit,
    modifier: Modifier = Modifier
) {
    val metrics by mainViewModel.dashboardMetrics.collectAsState()
    val settings by mainViewModel.companySettings.collectAsState()
    val todayDate = DateUtils.getTodayDate()
    val displayDate = DateUtils.formatToDisplayDate(todayDate)

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Welcome Banner Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
            shape = RoundedCornerShape(20.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = settings.companyName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "$displayDate • ${DateUtils.getDayOfWeek(todayDate)}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Surface(
                            color = if (currentUser.role == UserRole.OWNER) AccentAmber else PrimaryBlue,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = currentUser.role.name,
                                color = Color.White,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        Text(
                            text = "Signed in as ${currentUser.displayName}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }
        }

        // Quick Roll Call Action Banner
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onNavigateToAttendance() }
                .testTag("quick_attendance_card"),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            shape = RoundedCornerShape(16.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(StatusPresentBg),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.FactCheck,
                            contentDescription = null,
                            tint = StatusPresent,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Column {
                        Text(
                            text = "Daily Roll Call & Attendance",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Tap to mark or adjust attendance for today",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Icon(
                    Icons.Default.ChevronRight,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Key Attendance Counters Grid
        Text(
            text = "Today's Attendance Status",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            MetricStatCard(
                title = "Present",
                count = metrics.presentToday.toString(),
                containerColor = StatusPresentBg,
                contentColor = StatusPresent,
                icon = Icons.Default.Check,
                modifier = Modifier.weight(1f)
            )
            MetricStatCard(
                title = "Absent",
                count = metrics.absentToday.toString(),
                containerColor = StatusAbsentBg,
                contentColor = StatusAbsent,
                icon = Icons.Default.Close,
                modifier = Modifier.weight(1f)
            )
            MetricStatCard(
                title = "On Leave",
                count = metrics.onLeaveToday.toString(),
                containerColor = StatusLeaveBg,
                contentColor = StatusLeave,
                icon = Icons.Default.FlightTakeoff,
                modifier = Modifier.weight(1f)
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            MetricStatCard(
                title = "Half Day",
                count = metrics.halfDayToday.toString(),
                containerColor = StatusHalfDayBg,
                contentColor = StatusHalfDay,
                icon = Icons.Default.AccessTime,
                modifier = Modifier.weight(1f)
            )
            MetricStatCard(
                title = "Week Off",
                count = metrics.weekOffToday.toString(),
                containerColor = StatusWeekOffBg,
                contentColor = StatusWeekOff,
                icon = Icons.Default.Weekend,
                modifier = Modifier.weight(1f)
            )
            MetricStatCard(
                title = "Holiday",
                count = metrics.holidayToday.toString(),
                containerColor = StatusHolidayBg,
                contentColor = StatusHoliday,
                icon = Icons.Default.Event,
                modifier = Modifier.weight(1f)
            )
        }

        // Visual Proportion Bar
        val totalMarked = metrics.presentToday + metrics.absentToday + metrics.onLeaveToday + metrics.halfDayToday
        if (totalMarked > 0) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    val rate = (metrics.presentToday + metrics.halfDayToday * 0.5) / totalMarked * 100.0
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Today's Attendance Rate",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "%.1f%%".format(rate),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = StatusPresent
                        )
                    }

                    // Multi-segment linear gauge
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(10.dp)
                            .clip(RoundedCornerShape(5.dp))
                    ) {
                        if (metrics.presentToday > 0) {
                            Box(modifier = Modifier.weight(metrics.presentToday.toFloat()).fillMaxHeight().background(StatusPresent))
                        }
                        if (metrics.halfDayToday > 0) {
                            Box(modifier = Modifier.weight(metrics.halfDayToday.toFloat()).fillMaxHeight().background(StatusHalfDay))
                        }
                        if (metrics.onLeaveToday > 0) {
                            Box(modifier = Modifier.weight(metrics.onLeaveToday.toFloat()).fillMaxHeight().background(StatusLeave))
                        }
                        if (metrics.absentToday > 0) {
                            Box(modifier = Modifier.weight(metrics.absentToday.toFloat()).fillMaxHeight().background(StatusAbsent))
                        }
                    }
                }
            }
        }

        // Secondary Metrics: Staff & Overtime
        Text(
            text = "Staff & Overtime Summary",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Card(
                modifier = Modifier
                    .weight(1f)
                    .clickable { onNavigateToEmployees() },
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.People, contentDescription = null, tint = PrimaryBlue, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Active Staff", style = MaterialTheme.typography.labelMedium)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "${metrics.activeEmployees} / ${metrics.totalEmployees}",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Card(
                modifier = Modifier
                    .weight(1f)
                    .clickable { onNavigateToOvertime() },
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Timer, contentDescription = null, tint = AccentAmber, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Pending OT", style = MaterialTheme.typography.labelMedium)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "${metrics.pendingOtCount} requests",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (metrics.pendingOtCount > 0) AccentAmber else MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }

        // Action shortcuts
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedButton(
                onClick = { onNavigateToReports() },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Assessment, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Reports & Export")
            }

            OutlinedButton(
                onClick = { onNavigateToOvertime() },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Approval, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Manage OT")
            }
        }
    }
}

@Composable
fun MetricStatCard(
    title: String,
    count: String,
    containerColor: Color,
    contentColor: Color,
    icon: ImageVector,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = containerColor),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelMedium,
                    color = contentColor,
                    fontWeight = FontWeight.SemiBold
                )
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = contentColor,
                    modifier = Modifier.size(16.dp)
                )
            }
            Text(
                text = count,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = contentColor
            )
        }
    }
}
