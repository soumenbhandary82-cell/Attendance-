package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.AttendanceRecord
import com.example.data.model.AttendanceStatus
import com.example.data.model.Employee
import com.example.data.model.Holiday
import com.example.data.model.OvertimeRecord
import com.example.data.repository.AttendanceRepository
import com.example.util.DateUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn

data class EmployeeMonthlySummary(
    val presentCount: Int = 0,
    val absentCount: Int = 0,
    val leaveCount: Int = 0,
    val halfDayCount: Int = 0,
    val weekOffCount: Int = 0,
    val holidayCount: Int = 0,
    val totalApprovedOtHours: Double = 0.0,
    val attendancePercentage: Double = 0.0
)

class EmployeeViewModel(
    private val repository: AttendanceRepository,
    val employeeId: String
) : ViewModel() {

    val employeeProfile: StateFlow<Employee?> = repository.getEmployeeFlow(employeeId)
        .stateIn(viewModelScope, SharingStarted.Lazily, null)

    private val _selectedMonth = MutableStateFlow(DateUtils.getCurrentMonth())
    val selectedMonth: StateFlow<String> = _selectedMonth.asStateFlow()

    val myAttendance: StateFlow<List<AttendanceRecord>> = _selectedMonth.flatMapLatest { month ->
        repository.getAttendanceForEmployeeInMonth(employeeId, month)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val myApprovedOvertime: StateFlow<List<OvertimeRecord>> = _selectedMonth.flatMapLatest { month ->
        repository.getApprovedOtForEmployeeInMonth(employeeId, month)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val holidays: StateFlow<List<Holiday>> = _selectedMonth.flatMapLatest { month ->
        repository.getHolidaysForMonth(month)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val monthlySummary: StateFlow<EmployeeMonthlySummary> = combine(
        myAttendance,
        myApprovedOvertime
    ) { attendanceList, otList ->
        val present = attendanceList.count { it.status == AttendanceStatus.PRESENT }
        val absent = attendanceList.count { it.status == AttendanceStatus.ABSENT }
        val leave = attendanceList.count { it.status == AttendanceStatus.LEAVE }
        val halfDay = attendanceList.count { it.status == AttendanceStatus.HALF_DAY }
        val weekOff = attendanceList.count { it.status == AttendanceStatus.WEEK_OFF }
        val holiday = attendanceList.count { it.status == AttendanceStatus.HOLIDAY }
        val otHours = otList.sumOf { it.hours }

        // Standard working days calculation: (present + absent + leave + halfDay)
        val workingDays = present + absent + leave + halfDay
        val effectiveAttendance = present + (halfDay * 0.5)
        val percentage = if (workingDays > 0) {
            (effectiveAttendance / workingDays) * 100.0
        } else {
            100.0
        }

        EmployeeMonthlySummary(
            presentCount = present,
            absentCount = absent,
            leaveCount = leave,
            halfDayCount = halfDay,
            weekOffCount = weekOff,
            holidayCount = holiday,
            totalApprovedOtHours = otHours,
            attendancePercentage = percentage
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), EmployeeMonthlySummary())

    fun setSelectedMonth(month: String) {
        _selectedMonth.value = month
    }
}

class EmployeeViewModelFactory(
    private val repository: AttendanceRepository,
    private val employeeId: String
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(EmployeeViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return EmployeeViewModel(repository, employeeId) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
