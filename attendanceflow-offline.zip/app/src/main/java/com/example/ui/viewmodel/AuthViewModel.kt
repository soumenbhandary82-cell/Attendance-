package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.AppUser
import com.example.data.model.UserRole
import com.example.data.repository.AttendanceRepository
import com.example.data.security.SecurityHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class UserSession(
    val userId: String,
    val displayName: String,
    val role: UserRole,
    val employeeId: String? = null,
    val canApproveOt: Boolean = true,
    val canManageHolidays: Boolean = true,
    val canExportReports: Boolean = true
)

data class AuthUiState(
    val isCheckingFirstRun: Boolean = true,
    val isFirstRun: Boolean = false,
    val loggedInUser: UserSession? = null,
    val errorMessage: String? = null,
    val successMessage: String? = null,
    val failedAttempts: Int = 0,
    val isLockedOut: Boolean = false,
    val lockRemainingSeconds: Int = 0
)

class AuthViewModel(private val repository: AttendanceRepository) : ViewModel() {

    private val _uiState = MutableStateFlow(AuthUiState())
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    init {
        checkFirstRun()
    }

    private fun checkFirstRun() {
        viewModelScope.launch {
            val ownerCount = repository.countOwners()
            _uiState.value = _uiState.value.copy(
                isCheckingFirstRun = false,
                isFirstRun = ownerCount == 0
            )
        }
    }

    fun createOwner(
        ownerName: String,
        ownerId: String,
        pin: String,
        confirmPin: String
    ) {
        if (ownerName.isBlank()) {
            _uiState.value = _uiState.value.copy(errorMessage = "Owner name cannot be blank")
            return
        }
        if (ownerId.isBlank()) {
            _uiState.value = _uiState.value.copy(errorMessage = "Owner ID cannot be blank")
            return
        }
        if (pin.length < 4) {
            _uiState.value = _uiState.value.copy(errorMessage = "PIN must be at least 4 digits/characters")
            return
        }
        if (pin != confirmPin) {
            _uiState.value = _uiState.value.copy(errorMessage = "PINs do not match")
            return
        }

        viewModelScope.launch {
            try {
                val salt = SecurityHelper.generateSalt()
                val hash = SecurityHelper.hashPassword(pin, salt)
                val owner = AppUser(
                    username = ownerId.trim(),
                    passwordHash = hash,
                    salt = salt,
                    role = UserRole.OWNER,
                    displayName = ownerName.trim(),
                    canApproveOt = true,
                    canManageHolidays = true,
                    canExportReports = true,
                    isActive = true
                )
                repository.insertUser(owner)
                repository.logAction(
                    userId = ownerId,
                    userName = ownerName,
                    role = "OWNER",
                    action = "OWNER_SETUP",
                    details = "Owner account created during initial setup"
                )

                _uiState.value = _uiState.value.copy(
                    isFirstRun = false,
                    loggedInUser = UserSession(
                        userId = owner.username,
                        displayName = owner.displayName,
                        role = UserRole.OWNER
                    ),
                    errorMessage = null,
                    successMessage = "Owner account configured successfully"
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(errorMessage = "Failed to create Owner: ${e.localizedMessage}")
            }
        }
    }

    fun loginUser(
        role: UserRole,
        idInput: String,
        pinInput: String
    ) {
        val trimmedId = idInput.trim()
        val trimmedPin = pinInput.trim()

        if (trimmedId.isEmpty() || trimmedPin.isEmpty()) {
            _uiState.value = _uiState.value.copy(errorMessage = "Please enter ID and PIN")
            return
        }

        if (_uiState.value.isLockedOut) {
            _uiState.value = _uiState.value.copy(errorMessage = "Account temporarily locked due to failed attempts. Try again later.")
            return
        }

        viewModelScope.launch {
            if (role == UserRole.EMPLOYEE) {
                // Employee login checks employee table
                val emp = repository.getEmployeeByEmployeeId(trimmedId)
                if (emp == null) {
                    recordFailedLogin("Employee not found with ID: $trimmedId")
                    return@launch
                }
                if (!emp.isActive) {
                    _uiState.value = _uiState.value.copy(errorMessage = "This employee account is deactivated. Contact Administrator.")
                    return@launch
                }
                val valid = SecurityHelper.verifyPassword(trimmedPin, emp.salt, emp.pinHash)
                if (valid) {
                    _uiState.value = _uiState.value.copy(
                        loggedInUser = UserSession(
                            userId = emp.employeeId,
                            displayName = emp.name,
                            role = UserRole.EMPLOYEE,
                            employeeId = emp.employeeId
                        ),
                        errorMessage = null,
                        failedAttempts = 0
                    )
                    repository.logAction(emp.employeeId, emp.name, "EMPLOYEE", "LOGIN", "Employee logged in")
                } else {
                    recordFailedLogin("Invalid Employee PIN")
                }
            } else {
                // Owner / Admin login
                val user = repository.getUserByUsername(trimmedId)
                if (user == null || user.role != role) {
                    recordFailedLogin("User not found or role mismatch for ID: $trimmedId")
                    return@launch
                }
                if (!user.isActive) {
                    _uiState.value = _uiState.value.copy(errorMessage = "Account is disabled. Contact Owner.")
                    return@launch
                }
                val valid = SecurityHelper.verifyPassword(trimmedPin, user.salt, user.passwordHash)
                if (valid) {
                    _uiState.value = _uiState.value.copy(
                        loggedInUser = UserSession(
                            userId = user.username,
                            displayName = user.displayName,
                            role = user.role,
                            employeeId = user.employeeId,
                            canApproveOt = user.canApproveOt,
                            canManageHolidays = user.canManageHolidays,
                            canExportReports = user.canExportReports
                        ),
                        errorMessage = null,
                        failedAttempts = 0
                    )
                    repository.logAction(user.username, user.displayName, user.role.name, "LOGIN", "User logged in")
                } else {
                    recordFailedLogin("Invalid credentials for $role")
                }
            }
        }
    }

    private suspend fun recordFailedLogin(reason: String) {
        val attempts = _uiState.value.failedAttempts + 1
        val isLocked = attempts >= 5
        _uiState.value = _uiState.value.copy(
            failedAttempts = attempts,
            isLockedOut = isLocked,
            errorMessage = if (isLocked) "Too many failed attempts. Login locked." else "$reason (Attempt $attempts/5)"
        )
        repository.logAction("SYSTEM", "Auth", "SECURITY", "LOGIN_FAILED", reason)
    }

    fun logout() {
        val current = _uiState.value.loggedInUser
        if (current != null) {
            viewModelScope.launch {
                repository.logAction(current.userId, current.displayName, current.role.name, "LOGOUT", "User logged out")
            }
        }
        _uiState.value = _uiState.value.copy(
            loggedInUser = null,
            errorMessage = null,
            successMessage = null
        )
    }

    fun clearMessages() {
        _uiState.value = _uiState.value.copy(errorMessage = null, successMessage = null)
    }
}

class AuthViewModelFactory(private val repository: AttendanceRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(AuthViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return AuthViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
