package com.example.ui.screens

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.viewmodel.EmployeeMonthlyStat
import com.example.ui.viewmodel.MainViewModel
import com.example.util.DateUtils

@Composable
fun ReportsScreen(
    mainViewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentMonth by mainViewModel.reportsMonth.collectAsState()
    val monthlyStats by mainViewModel.reportsMonthlyStats.collectAsState()
    val departments by mainViewModel.distinctDepartments.collectAsState()

    var selectedDept by remember { mutableStateOf("All") }

    val filteredStats = monthlyStats.filter { stat ->
        selectedDept == "All" || stat.department.equals(selectedDept, ignoreCase = true)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Month Selector Header
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(16.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(
                    onClick = {
                        mainViewModel.setReportsMonth(DateUtils.getPreviousMonth(currentMonth))
                    }
                ) {
                    Icon(Icons.Default.ChevronLeft, contentDescription = "Previous Month")
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = DateUtils.formatMonthDisplayName(currentMonth),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Monthly Attendance & Overtime Report",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                IconButton(
                    onClick = {
                        mainViewModel.setReportsMonth(DateUtils.getNextMonth(currentMonth))
                    }
                ) {
                    Icon(Icons.Default.ChevronRight, contentDescription = "Next Month")
                }
            }
        }

        // Export Action Buttons Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = { mainViewModel.exportMonthlyCsv(context) },
                modifier = Modifier
                    .weight(1f)
                    .testTag("export_csv_button"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = SecondaryTeal)
            ) {
                Icon(Icons.Default.TableChart, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Export Excel (CSV)", fontSize = 13.sp)
            }

            Button(
                onClick = { mainViewModel.exportMonthlyPdf(context) },
                modifier = Modifier
                    .weight(1f)
                    .testTag("export_pdf_button"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryNavy)
            ) {
                Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Export PDF", fontSize = 13.sp)
            }
        }

        // Overall Monthly Summary Card
        val totalStaff = filteredStats.size
        val avgPercentage = if (totalStaff > 0) filteredStats.map { it.percentage }.average() else 0.0
        val totalOt = filteredStats.sumOf { it.approvedOtHours }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            shape = RoundedCornerShape(14.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Employees", style = MaterialTheme.typography.labelSmall)
                    Text("$totalStaff", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Avg Attendance", style = MaterialTheme.typography.labelSmall)
                    Text(
                        "%.1f%%".format(avgPercentage),
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium,
                        color = StatusPresent
                    )
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Total OT", style = MaterialTheme.typography.labelSmall)
                    Text(
                        "%.1f hrs".format(totalOt),
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium,
                        color = AccentAmber
                    )
                }
            }
        }

        // Table List
        if (filteredStats.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No employee records found for this month.\nMark attendance or navigate to another month.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filteredStats, key = { it.employeeId }) { stat ->
                    ReportItemCard(stat = stat)
                }
            }
        }
    }
}

@Composable
fun ReportItemCard(stat: EmployeeMonthlyStat) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(14.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = stat.employeeName,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${stat.employeeId} • ${stat.department}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Surface(
                    color = if (stat.percentage >= 80.0) StatusPresentBg else StatusAbsentBg,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = "%.1f%%".format(stat.percentage),
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.labelMedium,
                        color = if (stat.percentage >= 80.0) StatusPresent else StatusAbsent,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            // Compact breakdown row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("P: ${stat.present}", style = MaterialTheme.typography.labelSmall, color = StatusPresent, fontWeight = FontWeight.Bold)
                Text("A: ${stat.absent}", style = MaterialTheme.typography.labelSmall, color = StatusAbsent, fontWeight = FontWeight.Bold)
                Text("L: ${stat.leave}", style = MaterialTheme.typography.labelSmall, color = StatusLeave, fontWeight = FontWeight.Bold)
                Text("HD: ${stat.halfDay}", style = MaterialTheme.typography.labelSmall, color = StatusHalfDay, fontWeight = FontWeight.Bold)
                Text("WO: ${stat.weekOff}", style = MaterialTheme.typography.labelSmall, color = StatusWeekOff)
                Text("H: ${stat.holiday}", style = MaterialTheme.typography.labelSmall, color = StatusHoliday)
                Text("OT: %.1fh".format(stat.approvedOtHours), style = MaterialTheme.typography.labelSmall, color = AccentAmber, fontWeight = FontWeight.Bold)
            }
        }
    }
}
