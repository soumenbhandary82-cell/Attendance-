package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Employee
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel

@Composable
fun EmployeeManagementScreen(
    mainViewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val employees by mainViewModel.allEmployees.collectAsState()
    val shifts by mainViewModel.allShifts.collectAsState()
    val departments by mainViewModel.distinctDepartments.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var selectedDept by remember { mutableStateOf("All") }
    var showInactiveOnly by remember { mutableStateOf<Boolean?>(null) } // null = all, true = active, false = inactive

    var showAddDialog by remember { mutableStateOf(false) }
    var employeeToEdit by remember { mutableStateOf<Employee?>(null) }
    var employeeToDelete by remember { mutableStateOf<Employee?>(null) }
    var showImportDialog by remember { mutableStateOf(false) }

    val filteredList = employees.filter { emp ->
        val matchesSearch = searchQuery.isBlank() ||
                emp.name.contains(searchQuery, ignoreCase = true) ||
                emp.employeeId.contains(searchQuery, ignoreCase = true) ||
                emp.department.contains(searchQuery, ignoreCase = true) ||
                emp.designation.contains(searchQuery, ignoreCase = true)

        val matchesDept = selectedDept == "All" || emp.department.equals(selectedDept, ignoreCase = true)
        val matchesActive = when (showInactiveOnly) {
            true -> emp.isActive
            false -> !emp.isActive
            null -> true
        }
        matchesSearch && matchesDept && matchesActive
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = PrimaryNavy,
                contentColor = Color.White,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.testTag("add_employee_fab")
            ) {
                Icon(Icons.Default.PersonAdd, contentDescription = "Add Employee")
            }
        }
    ) { paddingValues ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header & CSV Import button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Employee Directory",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${filteredList.size} of ${employees.size} total employees",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                OutlinedButton(
                    onClick = { showImportDialog = true },
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier.testTag("import_csv_button")
                ) {
                    Icon(Icons.Default.UploadFile, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Import CSV", fontSize = 12.sp)
                }
            }

            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search by name, ID, department...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Close, contentDescription = "Clear")
                        }
                    }
                },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("employee_search_bar"),
                shape = RoundedCornerShape(12.dp)
            )

            // Filter Chips Row
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                item {
                    FilterChip(
                        selected = showInactiveOnly == null,
                        onClick = { showInactiveOnly = null },
                        label = { Text("All Status") }
                    )
                }
                item {
                    FilterChip(
                        selected = showInactiveOnly == true,
                        onClick = { showInactiveOnly = true },
                        label = { Text("Active") }
                    )
                }
                item {
                    FilterChip(
                        selected = showInactiveOnly == false,
                        onClick = { showInactiveOnly = false },
                        label = { Text("Deactivated") }
                    )
                }

                items(departments) { dept ->
                    FilterChip(
                        selected = selectedDept.equals(dept, ignoreCase = true),
                        onClick = {
                            selectedDept = if (selectedDept == dept) "All" else dept
                        },
                        label = { Text(dept) }
                    )
                }
            }

            // List of Employees
            if (filteredList.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Default.PeopleOutline,
                            contentDescription = null,
                            modifier = Modifier.size(56.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (employees.isEmpty()) "No employees in database.\nTap the + button to add the first employee." else "No employees match your search criteria.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredList, key = { it.employeeId }) { emp ->
                        EmployeeItemCard(
                            employee = emp,
                            onEdit = { employeeToEdit = emp },
                            onToggleActive = { mainViewModel.toggleEmployeeActive(emp) },
                            onDelete = { employeeToDelete = emp }
                        )
                    }
                }
            }
        }
    }

    // Dialogs
    if (showAddDialog) {
        AddEditEmployeeDialog(
            employee = null,
            shifts = shifts,
            onDismiss = { showAddDialog = false },
            onSave = { id, name, pin, mobile, dept, desig, joining, shift, notes ->
                mainViewModel.addEmployee(id, name, pin, mobile, dept, desig, joining, shift, notes)
            }
        )
    }

    if (employeeToEdit != null) {
        AddEditEmployeeDialog(
            employee = employeeToEdit,
            shifts = shifts,
            onDismiss = { employeeToEdit = null },
            onSave = { _, name, pin, mobile, dept, desig, joining, shift, notes ->
                val updated = employeeToEdit!!.copy(
                    name = name,
                    mobileNumber = mobile,
                    department = dept,
                    designation = desig,
                    joiningDate = joining,
                    defaultShiftName = shift,
                    notes = notes
                )
                mainViewModel.updateEmployee(updated, pin.ifBlank { null })
                employeeToEdit = null
            }
        )
    }

    if (employeeToDelete != null) {
        AlertDialog(
            onDismissRequest = { employeeToDelete = null },
            title = { Text("Delete Employee Record?") },
            text = {
                Text("Are you sure you want to delete ${employeeToDelete?.name} (${employeeToDelete?.employeeId})? Historical attendance will remain stored in the database.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        employeeToDelete?.let { mainViewModel.deleteEmployee(it) }
                        employeeToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { employeeToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (showImportDialog) {
        CsvImportDialog(
            onDismiss = { showImportDialog = false },
            onImport = { csv ->
                mainViewModel.importEmployeesFromCsv(csv)
            }
        )
    }
}

@Composable
fun EmployeeItemCard(
    employee: Employee,
    onEdit: () -> Unit,
    onToggleActive: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("employee_item_${employee.employeeId}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(if (employee.isActive) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = employee.name.take(1).uppercase(),
                            fontWeight = FontWeight.Bold,
                            color = if (employee.isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 16.sp
                        )
                    }

                    Column {
                        Text(
                            text = employee.name,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${employee.employeeId} • ${employee.designation}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Surface(
                    color = if (employee.isActive) StatusPresentBg else StatusAbsentBg,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = if (employee.isActive) "Active" else "Deactivated",
                        color = if (employee.isActive) StatusPresent else StatusAbsent,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Divider()

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Dept: ${employee.department}  |  Shift: ${employee.defaultShiftName}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (employee.joiningDate.isNotBlank()) {
                        Text(
                            text = "Joined: ${employee.joiningDate}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    IconButton(onClick = onEdit, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit", modifier = Modifier.size(18.dp))
                    }
                    IconButton(onClick = onToggleActive, modifier = Modifier.size(32.dp)) {
                        Icon(
                            imageVector = if (employee.isActive) Icons.Default.Block else Icons.Default.CheckCircle,
                            contentDescription = if (employee.isActive) "Deactivate" else "Reactivate",
                            tint = if (employee.isActive) AccentAmber else StatusPresent,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = StatusAbsent, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }
}
