package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.OvertimeRecord
import com.example.data.model.OvertimeStatus
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel

@Composable
fun OvertimeScreen(
    mainViewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val pendingOt by mainViewModel.pendingOvertime.collectAsState()
    val allOt by mainViewModel.allOvertime.collectAsState()
    val employees by mainViewModel.activeEmployees.collectAsState()

    var selectedTabIndex by remember { mutableStateOf(0) }
    var showSubmitDialog by remember { mutableStateOf(false) }

    val displayedList = if (selectedTabIndex == 0) pendingOt else allOt

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showSubmitDialog = true },
                containerColor = PrimaryNavy,
                contentColor = Color.White,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.testTag("log_ot_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Log Overtime")
            }
        }
    ) { paddingValues ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = "Overtime Management",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            // Tabs
            TabRow(
                selectedTabIndex = selectedTabIndex,
                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(12.dp)
            ) {
                Tab(
                    selected = selectedTabIndex == 0,
                    onClick = { selectedTabIndex = 0 },
                    text = {
                        Text(
                            "Pending (${pendingOt.size})",
                            fontWeight = FontWeight.Bold,
                            color = if (selectedTabIndex == 0 && pendingOt.isNotEmpty()) AccentAmber else MaterialTheme.colorScheme.onSurface
                        )
                    }
                )
                Tab(
                    selected = selectedTabIndex == 1,
                    onClick = { selectedTabIndex = 1 },
                    text = { Text("All Records (${allOt.size})", fontWeight = FontWeight.Bold) }
                )
            }

            if (displayedList.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Default.CheckCircleOutline,
                            contentDescription = null,
                            modifier = Modifier.size(52.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (selectedTabIndex == 0) "No pending overtime requests!" else "No overtime records recorded yet.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(displayedList, key = { it.id }) { ot ->
                        OvertimeItemCard(
                            ot = ot,
                            onApprove = { mainViewModel.approveOvertime(ot) },
                            onReject = { mainViewModel.rejectOvertime(ot) }
                        )
                    }
                }
            }
        }
    }

    if (showSubmitDialog) {
        SubmitOvertimeDialog(
            employees = employees,
            onDismiss = { showSubmitDialog = false },
            onSubmit = { empId, empName, date, shift, start, end, hours, reason ->
                mainViewModel.submitOvertime(empId, empName, date, shift, start, end, hours, reason)
            }
        )
    }
}

@Composable
fun OvertimeItemCard(
    ot: OvertimeRecord,
    onApprove: () -> Unit,
    onReject: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("ot_card_${ot.id}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = ot.employeeName,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${ot.employeeId}  •  ${ot.date}  •  ${ot.shiftName}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Surface(
                    color = when (ot.status) {
                        OvertimeStatus.APPROVED -> StatusPresentBg
                        OvertimeStatus.REJECTED -> StatusAbsentBg
                        OvertimeStatus.PENDING -> StatusLeaveBg
                    },
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = ot.status.name,
                        color = when (ot.status) {
                            OvertimeStatus.APPROVED -> StatusPresent
                            OvertimeStatus.REJECTED -> StatusAbsent
                            OvertimeStatus.PENDING -> AccentAmber
                        },
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Text(
                text = "Hours: %.1f hrs (${ot.startTime} - ${ot.endTime})".format(ot.hours),
                fontWeight = FontWeight.SemiBold,
                style = MaterialTheme.typography.bodyMedium
            )

            if (ot.reason.isNotBlank()) {
                Text(
                    text = "Reason: ${ot.reason}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (ot.status == OvertimeStatus.APPROVED && ot.approvedBy.isNotBlank()) {
                Text(
                    text = "Approved by: ${ot.approvedBy}",
                    style = MaterialTheme.typography.labelSmall,
                    color = StatusPresent
                )
            }

            // Approval Actions if Pending
            if (ot.status == OvertimeStatus.PENDING) {
                Divider()
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = onReject,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusAbsent),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("reject_ot_button_${ot.id}")
                    ) {
                        Text("Reject", fontSize = 12.sp)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = onApprove,
                        colors = ButtonDefaults.buttonColors(containerColor = StatusPresent),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("approve_ot_button_${ot.id}")
                    ) {
                        Text("Approve", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}
