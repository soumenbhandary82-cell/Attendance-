package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.data.model.Employee
import com.example.data.model.Holiday
import com.example.data.model.Shift
import com.example.util.DateUtils

@Composable
fun AddEditEmployeeDialog(
    employee: Employee? = null,
    shifts: List<Shift>,
    onDismiss: () -> Unit,
    onSave: (
        employeeId: String,
        name: String,
        pin: String,
        mobile: String,
        dept: String,
        designation: String,
        joiningDate: String,
        shiftName: String,
        notes: String
    ) -> Unit
) {
    var empId by remember { mutableStateOf(employee?.employeeId ?: "") }
    var name by remember { mutableStateOf(employee?.name ?: "") }
    var pin by remember { mutableStateOf("") }
    var mobile by remember { mutableStateOf(employee?.mobileNumber ?: "") }
    var dept by remember { mutableStateOf(employee?.department ?: "General") }
    var designation by remember { mutableStateOf(employee?.designation ?: "Staff") }
    var joiningDate by remember { mutableStateOf(employee?.joiningDate ?: DateUtils.getTodayDate()) }
    var selectedShift by remember { mutableStateOf(employee?.defaultShiftName ?: if (shifts.isNotEmpty()) shifts[0].name else "A Shift") }
    var notes by remember { mutableStateOf(employee?.notes ?: "") }
    var shiftMenuExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (employee == null) "Add New Employee" else "Edit Employee",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = empId,
                    onValueChange = { empId = it },
                    label = { Text("Employee ID * (e.g. EMP001)") },
                    enabled = employee == null, // ID immutable after creation
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Full Name *") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = pin,
                    onValueChange = { pin = it },
                    label = { Text(if (employee == null) "Employee PIN * (min 4 digits)" else "New PIN (leave blank to keep)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = mobile,
                    onValueChange = { mobile = it },
                    label = { Text("Mobile Number (Optional)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = dept,
                    onValueChange = { dept = it },
                    label = { Text("Department") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = designation,
                    onValueChange = { designation = it },
                    label = { Text("Designation") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = joiningDate,
                    onValueChange = { joiningDate = it },
                    label = { Text("Joining Date (YYYY-MM-DD)") },
                    modifier = Modifier.fillMaxWidth()
                )

                // Shift dropdown
                Box(modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(
                        onClick = { shiftMenuExpanded = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Default Shift: $selectedShift")
                    }
                    DropdownMenu(
                        expanded = shiftMenuExpanded,
                        onDismissRequest = { shiftMenuExpanded = false }
                    ) {
                        shifts.forEach { shift ->
                            DropdownMenuItem(
                                text = { Text("${shift.name} (${shift.startTime} - ${shift.endTime})") },
                                onClick = {
                                    selectedShift = shift.name
                                    shiftMenuExpanded = false
                                }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes (Optional)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (empId.isNotBlank() && name.isNotBlank()) {
                        onSave(empId, name, pin, mobile, dept, designation, joiningDate, selectedShift, notes)
                        onDismiss()
                    }
                }
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun AddEditShiftDialog(
    shift: Shift? = null,
    onDismiss: () -> Unit,
    onSave: (name: String, start: String, end: String, breakMin: Int, desc: String) -> Unit
) {
    var name by remember { mutableStateOf(shift?.name ?: "") }
    var start by remember { mutableStateOf(shift?.startTime ?: "09:00") }
    var end by remember { mutableStateOf(shift?.endTime ?: "17:00") }
    var breakMinText by remember { mutableStateOf(shift?.breakMinutes?.toString() ?: "30") }
    var desc by remember { mutableStateOf(shift?.description ?: "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (shift == null) "Add Shift" else "Edit Shift", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Shift Name (e.g. A Shift)") },
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = start,
                        onValueChange = { start = it },
                        label = { Text("Start (HH:mm)") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = end,
                        onValueChange = { end = it },
                        label = { Text("End (HH:mm)") },
                        modifier = Modifier.weight(1f)
                    )
                }
                OutlinedTextField(
                    value = breakMinText,
                    onValueChange = { breakMinText = it },
                    label = { Text("Break Minutes") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = desc,
                    onValueChange = { desc = it },
                    label = { Text("Description") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        val breakMin = breakMinText.toIntOrNull() ?: 30
                        onSave(name, start, end, breakMin, desc)
                        onDismiss()
                    }
                }
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun AddHolidayDialog(
    onDismiss: () -> Unit,
    onSave: (name: String, date: String, desc: String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(DateUtils.getTodayDate()) }
    var desc by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Holiday", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Holiday Name (e.g. Labor Day)") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = date,
                    onValueChange = { date = it },
                    label = { Text("Date (YYYY-MM-DD)") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = desc,
                    onValueChange = { desc = it },
                    label = { Text("Description (Optional)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank() && date.isNotBlank()) {
                        onSave(name, date, desc)
                        onDismiss()
                    }
                }
            ) {
                Text("Add")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun SubmitOvertimeDialog(
    employees: List<Employee>,
    onDismiss: () -> Unit,
    onSubmit: (
        employeeId: String,
        employeeName: String,
        date: String,
        shift: String,
        start: String,
        end: String,
        hours: Double,
        reason: String
    ) -> Unit
) {
    var selectedEmployee by remember { mutableStateOf(employees.firstOrNull()) }
    var empMenuExpanded by remember { mutableStateOf(false) }
    var date by remember { mutableStateOf(DateUtils.getTodayDate()) }
    var startTime by remember { mutableStateOf("17:00") }
    var endTime by remember { mutableStateOf("20:00") }
    var hoursText by remember { mutableStateOf("3.0") }
    var reason by remember { mutableStateOf("Project rush work") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Log Overtime", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(
                        onClick = { empMenuExpanded = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(selectedEmployee?.let { "${it.name} (${it.employeeId})" } ?: "Select Employee")
                    }
                    DropdownMenu(
                        expanded = empMenuExpanded,
                        onDismissRequest = { empMenuExpanded = false }
                    ) {
                        employees.forEach { emp ->
                            DropdownMenuItem(
                                text = { Text("${emp.name} (${emp.employeeId})") },
                                onClick = {
                                    selectedEmployee = emp
                                    empMenuExpanded = false
                                }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = date,
                    onValueChange = { date = it },
                    label = { Text("Date (YYYY-MM-DD)") },
                    modifier = Modifier.fillMaxWidth()
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = startTime,
                        onValueChange = { startTime = it },
                        label = { Text("Start Time") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = endTime,
                        onValueChange = { endTime = it },
                        label = { Text("End Time") },
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = hoursText,
                    onValueChange = { hoursText = it },
                    label = { Text("OT Hours (e.g. 2.5)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = reason,
                    onValueChange = { reason = it },
                    label = { Text("Reason / Remarks") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val emp = selectedEmployee
                    val h = hoursText.toDoubleOrNull() ?: 0.0
                    if (emp != null && h > 0) {
                        onSubmit(emp.employeeId, emp.name, date, emp.defaultShiftName, startTime, endTime, h, reason)
                        onDismiss()
                    }
                }
            ) {
                Text("Submit")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun CsvImportDialog(
    onDismiss: () -> Unit,
    onImport: (csvText: String) -> Unit
) {
    var csvInput by remember {
        mutableStateOf(
            "Employee ID,Name,Department,Designation,Joining Date,Default Shift\n" +
            "EMP101,John Smith,Engineering,Lead Developer,2025-01-15,A Shift\n" +
            "EMP102,Sara Davis,Operations,Supervisor,2025-02-01,B Shift\n" +
            "EMP103,Michael Brown,Logistics,Associate,2025-03-10,C Shift"
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Import Employees from CSV", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    "Format: Employee ID, Name, Department, Designation, Joining Date, Default Shift",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedTextField(
                    value = csvInput,
                    onValueChange = { csvInput = it },
                    label = { Text("CSV Data") },
                    minLines = 6,
                    maxLines = 10,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    "Note: Existing IDs will be updated. Default PIN for new imports is '1234'.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        },
        confirmButton = {
            Button(onClick = {
                onImport(csvInput)
                onDismiss()
            }) {
                Text("Import")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun AddAdminDialog(
    onDismiss: () -> Unit,
    onSave: (username: String, pin: String, displayName: String) -> Unit
) {
    var username by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var displayName by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create Admin Account", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = displayName,
                    onValueChange = { displayName = it },
                    label = { Text("Admin Full Name *") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = username,
                    onValueChange = { username = it },
                    label = { Text("Admin ID / Username *") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = pin,
                    onValueChange = { pin = it },
                    label = { Text("Admin PIN * (min 4 chars)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(onClick = {
                if (username.isNotBlank() && pin.length >= 4 && displayName.isNotBlank()) {
                    onSave(username, pin, displayName)
                    onDismiss()
                }
            }) {
                Text("Create Admin")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun RestoreWarningDialog(
    onDismiss: () -> Unit,
    onConfirm: (jsonText: String) -> Unit
) {
    var jsonText by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
        title = { Text("Restore Database", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    "WARNING: Restoring will overwrite existing data. It is strongly recommended to create a backup first.",
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.SemiBold
                )
                OutlinedTextField(
                    value = jsonText,
                    onValueChange = { jsonText = it },
                    label = { Text("Paste JSON Backup Content") },
                    minLines = 5,
                    maxLines = 10,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (jsonText.isNotBlank()) {
                        onConfirm(jsonText)
                        onDismiss()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
            ) {
                Text("Proceed with Restore")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
