package com.example.ui.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.AppUser
import com.example.data.model.AttendanceRecord
import com.example.data.model.AttendanceStatus
import com.example.data.model.AuditLog
import com.example.data.model.CompanySettings
import com.example.data.model.Employee
import com.example.data.model.Holiday
import com.example.data.model.OvertimeRecord
import com.example.data.model.OvertimeStatus
import com.example.data.model.Shift
import com.example.data.model.UserRole
import com.example.data.repository.AttendanceRepository
import com.example.data.security.SecurityHelper
import com.example.util.BackupHelper
import com.example.util.DateUtils
import com.example.util.ExportHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class DailyAttendanceRow(
    val employee: Employee,
    var status: AttendanceStatus = AttendanceStatus.PRESENT,
    var otHours: Double = 0.0,
    var remarks: String = "",
    var checkIn: String = "",
    var checkOut: String = "",
    var existingRecordId: Long = 0
)

data class DashboardMetrics(
    val totalEmployees: Int = 0,
    val activeEmployees: Int = 0,
    val presentToday: Int = 0,
    val absentToday: Int = 0,
    val onLeaveToday: Int = 0,
    val halfDayToday: Int = 0,
    val weekOffToday: Int = 0,
    val holidayToday: Int = 0,
    val pendingOtCount: Int = 0,
    val approvedOtHoursThisMonth: Double = 0.0
)

class MainViewModel(
    private val repository: AttendanceRepository,
    private val currentUserProvider: () -> UserSession?
) : ViewModel() {

    // Common Flows
    val allEmployees = repository.allEmployees.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val activeEmployees = repository.activeEmployees.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val allShifts = repository.allShifts.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val allHolidays = repository.allHolidays.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val pendingOvertime = repository.pendingOvertime.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val allOvertime = repository.allOvertime.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val companySettings = repository.settingsFlow.stateIn(viewModelScope, SharingStarted.Lazily, CompanySettings())
    val allAdmins = repository.allAdmins.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val recentAuditLogs = repository.recentAuditLogs.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val distinctDepartments = repository.distinctDepartments.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    // Daily Attendance State
    private val _selectedAttendanceDate = MutableStateFlow(DateUtils.getTodayDate())
    val selectedAttendanceDate: StateFlow<String> = _selectedAttendanceDate.asStateFlow()

    private val _selectedDepartmentFilter = MutableStateFlow("All")
    val selectedDepartmentFilter: StateFlow<String> = _selectedDepartmentFilter.asStateFlow()

    private val _selectedShiftFilter = MutableStateFlow("All")
    val selectedShiftFilter: StateFlow<String> = _selectedShiftFilter.asStateFlow()

    private val _dailyAttendanceRows = MutableStateFlow<List<DailyAttendanceRow>>(emptyList())
    val dailyAttendanceRows: StateFlow<List<DailyAttendanceRow>> = _dailyAttendanceRows.asStateFlow()

    // Status / Message snackbars
    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    // Calendar state
    private val _calendarMonth = MutableStateFlow(DateUtils.getCurrentMonth())
    val calendarMonth: StateFlow<String> = _calendarMonth.asStateFlow()

    // Reports state
    private val _reportStartDate = MutableStateFlow(DateUtils.getCurrentMonth() + "-01")
    val reportStartDate: StateFlow<String> = _reportStartDate.asStateFlow()

    private val _reportEndDate = MutableStateFlow(DateUtils.getTodayDate())
    val reportEndDate: StateFlow<String> = _reportEndDate.asStateFlow()

    private val _reportFilterDept = MutableStateFlow("All")
    val reportFilterDept: StateFlow<String> = _reportFilterDept.asStateFlow()

    private val _reportFilterStatus = MutableStateFlow("All")
    val reportFilterStatus: StateFlow<String> = _reportFilterStatus.asStateFlow()

    // Dashboard metrics Flow
    val dashboardMetrics: StateFlow<DashboardMetrics> = combine(
        allEmployees,
        repository.getAttendanceForDate(DateUtils.getTodayDate()),
        pendingOvertime,
        repository.getTotalApprovedOtHoursInMonth(DateUtils.getCurrentMonth())
    ) { employees, todayAttendance, pendingOt, totalApprovedOt ->
        DashboardMetrics(
            totalEmployees = employees.size,
            activeEmployees = employees.count { it.isActive },
            presentToday = todayAttendance.count { it.status == AttendanceStatus.PRESENT },
            absentToday = todayAttendance.count { it.status == AttendanceStatus.ABSENT },
            onLeaveToday = todayAttendance.count { it.status == AttendanceStatus.LEAVE },
            halfDayToday = todayAttendance.count { it.status == AttendanceStatus.HALF_DAY },
            weekOffToday = todayAttendance.count { it.status == AttendanceStatus.WEEK_OFF },
            holidayToday = todayAttendance.count { it.status == AttendanceStatus.HOLIDAY },
            pendingOtCount = pendingOt.size,
            approvedOtHoursThisMonth = totalApprovedOt ?: 0.0
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardMetrics())

    init {
        loadAttendanceForDate(_selectedAttendanceDate.value)
    }

    fun setSelectedDate(date: String) {
        _selectedAttendanceDate.value = date
        loadAttendanceForDate(date)
    }

    fun setSelectedDepartment(dept: String) {
        _selectedDepartmentFilter.value = dept
    }

    fun setSelectedShift(shift: String) {
        _selectedShiftFilter.value = shift
    }

    fun setCalendarMonth(month: String) {
        _calendarMonth.value = month
    }

    fun setReportDateRange(start: String, end: String) {
        _reportStartDate.value = start
        _reportEndDate.value = end
    }

    fun setReportFilterDept(dept: String) {
        _reportFilterDept.value = dept
    }

    fun setReportFilterStatus(status: String) {
        _reportFilterStatus.value = status
    }

    fun clearSnackbar() {
        _snackbarMessage.value = null
    }

    // Daily Attendance Logic
    fun loadAttendanceForDate(date: String) {
        viewModelScope.launch {
            val employees = repository.activeEmployees.first()
            val existingRecords = repository.getAttendanceForDateSync(date)
            val holiday = repository.getHolidayByDate(date)
            val settings = repository.getSettings()

            val existingMap = existingRecords.associateBy { it.employeeId }
            val dayOfWeek = DateUtils.getDayOfWeek(date)
            val isStandardWeekOff = dayOfWeek.equals(settings.defaultWeekOffDay, ignoreCase = true)

            val rows = employees.map { emp ->
                val existing = existingMap[emp.employeeId]
                if (existing != null) {
                    DailyAttendanceRow(
                        employee = emp,
                        status = existing.status,
                        otHours = existing.overtimeHours,
                        remarks = existing.remarks,
                        checkIn = existing.checkInTime,
                        checkOut = existing.checkOutTime,
                        existingRecordId = existing.id
                    )
                } else {
                    // Default logic: Holiday if holiday date, Week off if default week off day, else Present
                    val defaultStatus = when {
                        holiday != null -> AttendanceStatus.HOLIDAY
                        isStandardWeekOff || emp.defaultShiftName.contains("Week Off", ignoreCase = true) -> AttendanceStatus.WEEK_OFF
                        else -> AttendanceStatus.PRESENT
                    }
                    val defaultRemark = if (holiday != null) holiday.name else ""
                    DailyAttendanceRow(
                        employee = emp,
                        status = defaultStatus,
                        remarks = defaultRemark,
                        existingRecordId = 0
                    )
                }
            }
            _dailyAttendanceRows.value = rows
        }
    }

    fun updateRowStatus(employeeId: String, newStatus: AttendanceStatus) {
        _dailyAttendanceRows.value = _dailyAttendanceRows.value.map { row ->
            if (row.employee.employeeId == employeeId) {
                row.copy(status = newStatus)
            } else row
        }
    }

    fun updateRowOt(employeeId: String, otHours: Double) {
        _dailyAttendanceRows.value = _dailyAttendanceRows.value.map { row ->
            if (row.employee.employeeId == employeeId) {
                row.copy(otHours = otHours)
            } else row
        }
    }

    fun updateRowRemarks(employeeId: String, remarks: String) {
        _dailyAttendanceRows.value = _dailyAttendanceRows.value.map { row ->
            if (row.employee.employeeId == employeeId) {
                row.copy(remarks = remarks)
            } else row
        }
    }

    fun markAllPresent() {
        _dailyAttendanceRows.value = _dailyAttendanceRows.value.map { row ->
            row.copy(status = AttendanceStatus.PRESENT)
        }
        _snackbarMessage.value = "Marked all employees Present for ${_selectedAttendanceDate.value}"
    }

    fun markAllWeekOff() {
        _dailyAttendanceRows.value = _dailyAttendanceRows.value.map { row ->
            row.copy(status = AttendanceStatus.WEEK_OFF)
        }
        _snackbarMessage.value = "Marked all employees Week Off for ${_selectedAttendanceDate.value}"
    }

    fun saveAttendance() {
        val user = currentUserProvider() ?: return
        val date = _selectedAttendanceDate.value
        val rows = _dailyAttendanceRows.value

        viewModelScope.launch {
            try {
                val records = rows.map { row ->
                    AttendanceRecord(
                        id = row.existingRecordId,
                        employeeId = row.employee.employeeId,
                        employeeName = row.employee.name,
                        department = row.employee.department,
                        date = date,
                        shiftId = row.employee.defaultShiftId,
                        shiftName = row.employee.defaultShiftName,
                        status = row.status,
                        checkInTime = row.checkIn,
                        checkOutTime = row.checkOut,
                        overtimeHours = row.otHours,
                        remarks = row.remarks,
                        createdBy = if (row.existingRecordId > 0) user.displayName else user.displayName,
                        lastModifiedBy = user.displayName,
                        lastModifiedTimestamp = System.currentTimeMillis()
                    )
                }
                repository.saveAllAttendance(records)
                repository.logAction(
                    userId = user.userId,
                    userName = user.displayName,
                    role = user.role.name,
                    action = "ATTENDANCE_SAVED",
                    details = "Saved attendance for ${records.size} employees on $date"
                )
                _snackbarMessage.value = "Attendance saved successfully for $date!"
                loadAttendanceForDate(date)
            } catch (e: Exception) {
                _snackbarMessage.value = "Failed to save attendance: ${e.localizedMessage}"
            }
        }
    }

    // Employee CRUD
    fun addEmployee(
        employeeId: String,
        name: String,
        pin: String,
        mobile: String,
        department: String,
        designation: String,
        joiningDate: String,
        shiftName: String,
        notes: String
    ) {
        val user = currentUserProvider() ?: return
        val trimmedId = employeeId.trim().uppercase()
        val trimmedName = name.trim()
        val trimmedPin = pin.trim()

        if (trimmedId.isEmpty() || trimmedName.isEmpty()) {
            _snackbarMessage.value = "Employee ID and Name cannot be empty"
            return
        }
        if (trimmedPin.length < 4) {
            _snackbarMessage.value = "PIN must be at least 4 digits"
            return
        }

        viewModelScope.launch {
            try {
                val existing = repository.getEmployeeByEmployeeId(trimmedId)
                if (existing != null) {
                    _snackbarMessage.value = "Employee ID '$trimmedId' already exists!"
                    return@launch
                }
                val salt = SecurityHelper.generateSalt()
                val hash = SecurityHelper.hashPassword(trimmedPin, salt)
                val employee = Employee(
                    employeeId = trimmedId,
                    name = trimmedName,
                    pinHash = hash,
                    salt = salt,
                    mobileNumber = mobile.trim(),
                    department = department.trim().ifEmpty { "General" },
                    designation = designation.trim().ifEmpty { "Staff" },
                    joiningDate = joiningDate.trim().ifEmpty { DateUtils.getTodayDate() },
                    defaultShiftName = shiftName.trim().ifEmpty { "A Shift" },
                    isActive = true,
                    notes = notes.trim()
                )
                repository.insertEmployee(employee)
                repository.logAction(
                    userId = user.userId,
                    userName = user.displayName,
                    role = user.role.name,
                    action = "EMPLOYEE_CREATED",
                    details = "Added employee $trimmedName ($trimmedId)"
                )
                _snackbarMessage.value = "Employee '$trimmedName' added successfully"
            } catch (e: Exception) {
                _snackbarMessage.value = "Error adding employee: ${e.localizedMessage}"
            }
        }
    }

    fun updateEmployee(
        employee: Employee,
        newPin: String? = null
    ) {
        val user = currentUserProvider() ?: return
        viewModelScope.launch {
            try {
                val updated = if (!newPin.isNullOrBlank()) {
                    val salt = SecurityHelper.generateSalt()
                    val hash = SecurityHelper.hashPassword(newPin.trim(), salt)
                    employee.copy(pinHash = hash, salt = salt, updatedAt = System.currentTimeMillis())
                } else {
                    employee.copy(updatedAt = System.currentTimeMillis())
                }
                repository.updateEmployee(updated)
                repository.logAction(
                    userId = user.userId,
                    userName = user.displayName,
                    role = user.role.name,
                    action = "EMPLOYEE_EDITED",
                    details = "Updated employee ${updated.name} (${updated.employeeId})"
                )
                _snackbarMessage.value = "Employee updated successfully"
            } catch (e: Exception) {
                _snackbarMessage.value = "Error updating employee: ${e.localizedMessage}"
            }
        }
    }

    fun toggleEmployeeActive(employee: Employee) {
        val user = currentUserProvider() ?: return
        viewModelScope.launch {
            val updated = employee.copy(isActive = !employee.isActive, updatedAt = System.currentTimeMillis())
            repository.updateEmployee(updated)
            val action = if (updated.isActive) "Reactivated" else "Deactivated"
            repository.logAction(
                userId = user.userId,
                userName = user.displayName,
                role = user.role.name,
                action = "EMPLOYEE_STATUS_CHANGED",
                details = "$action employee ${employee.name} (${employee.employeeId})"
            )
            _snackbarMessage.value = "Employee ${employee.name} $action"
        }
    }

    fun deleteEmployee(employee: Employee) {
        val user = currentUserProvider() ?: return
        viewModelScope.launch {
            repository.deleteEmployee(employee)
            repository.logAction(
                userId = user.userId,
                userName = user.displayName,
                role = user.role.name,
                action = "EMPLOYEE_DELETED",
                details = "Deleted employee record for ${employee.name} (${employee.employeeId})"
            )
            _snackbarMessage.value = "Employee deleted successfully"
        }
    }

    // CSV Bulk Import
    fun importEmployeesFromCsv(csvText: String) {
        val user = currentUserProvider() ?: return
        viewModelScope.launch {
            var imported = 0
            var updated = 0
            var skipped = 0
            var errors = 0

            val lines = csvText.lines()
            for ((index, line) in lines.withIndex()) {
                if (index == 0 && (line.contains("ID") || line.contains("Name"))) continue
                if (line.isBlank()) continue
                val parts = line.split(",").map { it.trim().removeSurrounding("\"") }
                if (parts.size < 2) {
                    errors++
                    continue
                }
                val empId = parts[0].uppercase()
                val name = parts[1]
                val dept = parts.getOrNull(2) ?: "General"
                val desig = parts.getOrNull(3) ?: "Staff"
                val joining = parts.getOrNull(4) ?: DateUtils.getTodayDate()
                val shift = parts.getOrNull(5) ?: "A Shift"

                val existing = repository.getEmployeeByEmployeeId(empId)
                if (existing != null) {
                    val upd = existing.copy(name = name, department = dept, designation = desig, joiningDate = joining, defaultShiftName = shift)
                    repository.updateEmployee(upd)
                    updated++
                } else {
                    val defaultPin = "1234"
                    val salt = SecurityHelper.generateSalt()
                    val hash = SecurityHelper.hashPassword(defaultPin, salt)
                    val newEmp = Employee(
                        employeeId = empId,
                        name = name,
                        pinHash = hash,
                        salt = salt,
                        department = dept,
                        designation = desig,
                        joiningDate = joining,
                        defaultShiftName = shift,
                        notes = "Imported from CSV"
                    )
                    repository.insertEmployee(newEmp)
                    imported++
                }
            }
            repository.logAction(
                userId = user.userId,
                userName = user.displayName,
                role = user.role.name,
                action = "CSV_IMPORT",
                details = "Imported: $imported, Updated: $updated, Skipped: $skipped, Errors: $errors"
            )
            _snackbarMessage.value = "Import summary: $imported added, $updated updated, $errors errors"
        }
    }

    // Shifts
    fun addShift(name: String, startTime: String, endTime: String, breakMin: Int, desc: String) {
        val user = currentUserProvider() ?: return
        viewModelScope.launch {
            val shift = Shift(
                name = name.trim(),
                startTime = startTime.trim(),
                endTime = endTime.trim(),
                breakMinutes = breakMin,
                description = desc.trim(),
                isActive = true
            )
            repository.insertShift(shift)
            repository.logAction(user.userId, user.displayName, user.role.name, "SHIFT_CREATED", "Created shift $name")
            _snackbarMessage.value = "Shift '$name' created"
        }
    }

    fun updateShift(shift: Shift) {
        val user = currentUserProvider() ?: return
        viewModelScope.launch {
            repository.updateShift(shift)
            repository.logAction(user.userId, user.displayName, user.role.name, "SHIFT_UPDATED", "Updated shift ${shift.name}")
            _snackbarMessage.value = "Shift '${shift.name}' updated"
        }
    }

    // Overtime
    fun submitOvertime(
        employeeId: String,
        employeeName: String,
        date: String,
        shiftName: String,
        startTime: String,
        endTime: String,
        hours: Double,
        reason: String
    ) {
        val user = currentUserProvider() ?: return
        viewModelScope.launch {
            val ot = OvertimeRecord(
                employeeId = employeeId,
                employeeName = employeeName,
                date = date,
                shiftName = shiftName,
                startTime = startTime,
                endTime = endTime,
                hours = hours,
                reason = reason,
                status = OvertimeStatus.PENDING
            )
            repository.insertOvertime(ot)
            repository.logAction(user.userId, user.displayName, user.role.name, "OT_SUBMITTED", "OT of $hours hrs submitted for $employeeName")
            _snackbarMessage.value = "Overtime request submitted"
        }
    }

    fun approveOvertime(ot: OvertimeRecord) {
        val user = currentUserProvider() ?: return
        viewModelScope.launch {
            val updated = ot.copy(status = OvertimeStatus.APPROVED, approvedBy = user.displayName)
            repository.updateOvertime(updated)
            repository.logAction(user.userId, user.displayName, user.role.name, "OT_APPROVED", "Approved ${ot.hours}h OT for ${ot.employeeName}")
            _snackbarMessage.value = "Approved overtime for ${ot.employeeName}"
        }
    }

    fun rejectOvertime(ot: OvertimeRecord) {
        val user = currentUserProvider() ?: return
        viewModelScope.launch {
            val updated = ot.copy(status = OvertimeStatus.REJECTED, approvedBy = user.displayName)
            repository.updateOvertime(updated)
            repository.logAction(user.userId, user.displayName, user.role.name, "OT_REJECTED", "Rejected ${ot.hours}h OT for ${ot.employeeName}")
            _snackbarMessage.value = "Rejected overtime for ${ot.employeeName}"
        }
    }

    // Holidays
    fun addHoliday(name: String, date: String, desc: String) {
        val user = currentUserProvider() ?: return
        viewModelScope.launch {
            try {
                val holiday = Holiday(name = name.trim(), date = date.trim(), description = desc.trim())
                repository.insertHoliday(holiday)
                repository.logAction(user.userId, user.displayName, user.role.name, "HOLIDAY_CREATED", "Added holiday $name on $date")
                _snackbarMessage.value = "Holiday '$name' added"
            } catch (e: Exception) {
                _snackbarMessage.value = "Failed to add holiday: ${e.localizedMessage}"
            }
        }
    }

    fun deleteHoliday(holiday: Holiday) {
        val user = currentUserProvider() ?: return
        viewModelScope.launch {
            repository.deleteHoliday(holiday)
            repository.logAction(user.userId, user.displayName, user.role.name, "HOLIDAY_DELETED", "Deleted holiday ${holiday.name}")
            _snackbarMessage.value = "Holiday '${holiday.name}' deleted"
        }
    }

    // Admin Users (Owner only)
    fun createAdmin(username: String, pin: String, displayName: String) {
        val user = currentUserProvider() ?: return
        if (user.role != UserRole.OWNER) return
        viewModelScope.launch {
            try {
                val salt = SecurityHelper.generateSalt()
                val hash = SecurityHelper.hashPassword(pin, salt)
                val admin = AppUser(
                    username = username.trim(),
                    passwordHash = hash,
                    salt = salt,
                    role = UserRole.ADMIN,
                    displayName = displayName.trim(),
                    canApproveOt = true,
                    canManageHolidays = true,
                    canExportReports = true,
                    isActive = true
                )
                repository.insertUser(admin)
                repository.logAction(user.userId, user.displayName, "OWNER", "ADMIN_CREATED", "Created admin $displayName ($username)")
                _snackbarMessage.value = "Admin account '$displayName' created"
            } catch (e: Exception) {
                _snackbarMessage.value = "Error creating admin: ${e.localizedMessage}"
            }
        }
    }

    fun toggleAdminActive(admin: AppUser) {
        val user = currentUserProvider() ?: return
        if (user.role != UserRole.OWNER) return
        viewModelScope.launch {
            val updated = admin.copy(isActive = !admin.isActive)
            repository.updateUser(updated)
            val action = if (updated.isActive) "Enabled" else "Disabled"
            repository.logAction(user.userId, user.displayName, "OWNER", "ADMIN_STATUS_CHANGED", "$action admin ${admin.displayName}")
            _snackbarMessage.value = "Admin ${admin.displayName} $action"
        }
    }

    fun deleteAdmin(admin: AppUser) {
        val user = currentUserProvider() ?: return
        if (user.role != UserRole.OWNER) return
        viewModelScope.launch {
            repository.deleteUser(admin)
            repository.logAction(user.userId, user.displayName, "OWNER", "ADMIN_DELETED", "Deleted admin ${admin.displayName}")
            _snackbarMessage.value = "Admin ${admin.displayName} deleted"
        }
    }

    // Company Settings
    fun saveCompanySettings(settings: CompanySettings) {
        val user = currentUserProvider() ?: return
        if (user.role != UserRole.OWNER) return
        viewModelScope.launch {
            repository.saveSettings(settings)
            repository.logAction(user.userId, user.displayName, "OWNER", "SETTINGS_UPDATED", "Updated company configuration")
            _snackbarMessage.value = "Company settings updated"
        }
    }

    // Reports & Export
    fun exportReportCsv(context: Context, records: List<AttendanceRecord>, filename: String) {
        val settings = companySettings.value
        val csv = ExportHelper.generateCsv(records, settings)
        ExportHelper.shareCsv(context, csv, filename)
        val user = currentUserProvider()
        if (user != null) {
            viewModelScope.launch {
                repository.logAction(user.userId, user.displayName, user.role.name, "REPORT_EXPORT_CSV", "Exported $filename with ${records.size} records")
            }
        }
    }

    fun exportReportPdf(context: Context, title: String, dateRange: String, records: List<AttendanceRecord>) {
        val settings = companySettings.value
        ExportHelper.generateAndSharePdf(context, title, dateRange, records, settings)
        val user = currentUserProvider()
        if (user != null) {
            viewModelScope.launch {
                repository.logAction(user.userId, user.displayName, user.role.name, "REPORT_EXPORT_PDF", "Exported PDF $title with ${records.size} records")
            }
        }
    }

    // Backup & Restore
    fun generateBackup(context: Context) {
        val user = currentUserProvider() ?: return
        if (user.role != UserRole.OWNER) return
        viewModelScope.launch {
            try {
                val users = repository.getAllUsersSync()
                val employees = repository.getAllEmployeesSync()
                val shifts = repository.getAllShiftsSync()
                val attendance = repository.getAllAttendanceSync()
                val overtime = repository.getAllOvertimeSync()
                val holidays = repository.getAllHolidaysSync()
                val settings = repository.getSettings()

                val json = BackupHelper.createBackupJson(
                    users = users,
                    employees = employees,
                    shifts = shifts,
                    attendance = attendance,
                    overtime = overtime,
                    holidays = holidays,
                    settings = settings
                )
                BackupHelper.shareBackup(context, json)
                repository.logAction(user.userId, user.displayName, "OWNER", "BACKUP_CREATED", "Database backup created")
                _snackbarMessage.value = "Backup created successfully"
            } catch (e: Exception) {
                _snackbarMessage.value = "Backup failed: ${e.localizedMessage}"
            }
        }
    }

    fun restoreBackup(jsonString: String) {
        val user = currentUserProvider() ?: return
        if (user.role != UserRole.OWNER) return
        viewModelScope.launch {
            try {
                val data = BackupHelper.parseBackupJson(jsonString)
                repository.restoreDatabase(
                    users = data.users,
                    employees = data.employees,
                    shifts = data.shifts,
                    attendance = data.attendance,
                    overtime = data.overtime,
                    holidays = data.holidays,
                    settings = data.settings
                )
                repository.logAction(user.userId, user.displayName, "OWNER", "BACKUP_RESTORED", "Database restored from backup file")
                _snackbarMessage.value = "Database restored successfully!"
                loadAttendanceForDate(_selectedAttendanceDate.value)
            } catch (e: Exception) {
                _snackbarMessage.value = "Restore failed: ${e.localizedMessage}"
            }
        }
    }
}

class MainViewModelFactory(
    private val repository: AttendanceRepository,
    private val currentUserProvider: () -> UserSession?
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MainViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return MainViewModel(repository, currentUserProvider) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
