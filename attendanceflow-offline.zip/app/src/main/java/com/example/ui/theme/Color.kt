package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Brand - Corporate Indigo & Slate
val PrimaryNavy = Color(0xFF1E3A8A)
val PrimaryNavyDark = Color(0xFF172554)
val PrimaryBlue = Color(0xFF2563EB)
val SecondaryTeal = Color(0xFF0D9488)
val AccentAmber = Color(0xFFD97706)

// Neutral Canvas
val BackgroundLight = Color(0xFFF8FAFC)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFF1F5F9)
val TextPrimary = Color(0xFF0F172A)
val TextSecondary = Color(0xFF475569)
val TextMuted = Color(0xFF64748B)
val BorderLight = Color(0xFFE2E8F0)

// Dark Palette
val BackgroundDark = Color(0xFF0F172A)
val SurfaceDark = Color(0xFF1E293B)
val SurfaceVariantDark = Color(0xFF334155)
val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFF94A3B8)

// Status Tokens
val StatusPresent = Color(0xFF10B981) // Green
val StatusPresentBg = Color(0xFFD1FAE5)
val StatusAbsent = Color(0xFFEF4444) // Red
val StatusAbsentBg = Color(0xFFFEE2E2)
val StatusLeave = Color(0xFFF59E0B) // Amber
val StatusLeaveBg = Color(0xFFFEF3C7)
val StatusHalfDay = Color(0xFFF97316) // Orange
val StatusHalfDayBg = Color(0xFFFFEDD5)
val StatusWeekOff = Color(0xFF0284C7) // Sky Blue
val StatusWeekOffBg = Color(0xFFE0F2FE)
val StatusHoliday = Color(0xFF8B5CF6) // Purple
val StatusHolidayBg = Color(0xFFEDE9FE)
