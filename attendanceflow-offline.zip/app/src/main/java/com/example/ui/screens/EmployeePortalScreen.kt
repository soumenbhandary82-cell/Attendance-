package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AttendanceRecord
import com.example.data.model.AttendanceStatus
import com.example.ui.theme.*
import com.example.ui.viewmodel.EmployeeViewModel
import com.example.util.DateUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EmployeePortalScreen(
    employeeViewModel: EmployeeViewModel,
    onLogout: () -> Unit,
    modifier: Modifier = Modifier
) {
    val profile by employeeViewModel.employeeProfile.collectAsState()
    val currentMonth by employeeViewModel.selectedMonth.collectAsState()
    val attendanceList by employeeViewModel.myAttendance.collectAsState()
    val otList by employeeViewModel.myApprovedOvertime.collectAsState()
    val holidays by employeeViewModel.holidays.collectAsState()
    val summary by employeeViewModel.monthlySummary.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text("Employee Self Portal", fontWeight = FontWeight.Bold)
                },
                actions = {
                    IconButton(
                        onClick = onLogout,
                        modifier = Modifier.testTag("employee_logout_button")
                    ) {
                        Icon(Icons.Default.Logout, contentDescription = "Log Out")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = PrimaryNavy,
                    titleContentColor = Color.White,
                    actionIconContentColor = Color.White
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Profile Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = RoundedCornerShape(20.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .clip(CircleShape)
                            .background(PrimaryNavy),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = profile?.name?.take(1)?.uppercase() ?: "E",
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 22.sp
                        )
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = profile?.name ?: "Loading...",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(
                            text = "${profile?.employeeId}  •  ${profile?.designation ?: "Staff"}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                        )
                        Text(
                            text = "Dept: ${profile?.department ?: "General"}  •  Shift: ${profile?.defaultShiftName ?: "A Shift"}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                        )
                    }
                }
            }

            // Month Selector
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    IconButton(
                        onClick = {
                            employeeViewModel.setSelectedMonth(DateUtils.getPreviousMonth(currentMonth))
                        }
                    ) {
                        Icon(Icons.Default.ChevronLeft, contentDescription = "Previous Month")
                    }

                    Text(
                        text = DateUtils.formatMonthDisplayName(currentMonth),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )

                    IconButton(
                        onClick = {
                            employeeViewModel.setSelectedMonth(DateUtils.getNextMonth(currentMonth))
                        }
                    ) {
                        Icon(Icons.Default.ChevronRight, contentDescription = "Next Month")
                    }
                }
            }

            // Monthly Statistics Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Monthly Attendance Rate", style = MaterialTheme.typography.labelMedium)
                            Text(
                                text = "%.1f%%".format(summary.attendancePercentage),
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (summary.attendancePercentage >= 80.0) StatusPresent else StatusAbsent
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text("Approved Overtime", style = MaterialTheme.typography.labelMedium)
                            Text(
                                text = "%.1f hrs".format(summary.totalApprovedOtHours),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = AccentAmber
                            )
                        }
                    }

                    Divider()

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Present: ${summary.presentCount}", color = StatusPresent, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                        Text("Absent: ${summary.absentCount}", color = StatusAbsent, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                        Text("Leave: ${summary.leaveCount}", color = StatusLeave, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                        Text("Half Day: ${summary.halfDayCount}", color = StatusHalfDay, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                        Text("Week Off: ${summary.weekOffCount}", color = StatusWeekOff, style = MaterialTheme.typography.labelSmall)
                        Text("Holiday: ${summary.holidayCount}", color = StatusHoliday, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }

            // Attendance Log List
            Text(
                text = "My Attendance History",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )

            if (attendanceList.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No attendance records found for this month.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(attendanceList, key = { it.date }) { record ->
                        EmployeeAttendanceCard(record = record)
                    }
                }
            }
        }
    }
}

@Composable
fun EmployeeAttendanceCard(record: AttendanceRecord) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = "${DateUtils.formatToDisplayDate(record.date)} (${DateUtils.getDayOfWeek(record.date)})",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Shift: ${record.shiftName}  ${if (record.overtimeHours > 0) "• OT: ${record.overtimeHours}h" else ""}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (record.remarks.isNotBlank()) {
                    Text(
                        text = "Remark: ${record.remarks}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Surface(
                color = getStatusBgColor(record.status),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(
                    text = record.status.displayName,
                    color = getStatusTextColor(record.status),
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.labelMedium,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                )
            }
        }
    }
}
