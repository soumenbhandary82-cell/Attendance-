package com.example.ui.screens

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppUser
import com.example.data.model.UserRole
import com.example.ui.theme.AccentAmber
import com.example.ui.theme.PrimaryNavy
import com.example.ui.theme.StatusAbsent
import com.example.ui.theme.StatusPresent
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.UserSession

@Composable
fun SettingsScreen(
    mainViewModel: MainViewModel,
    currentUser: UserSession,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val settings by mainViewModel.companySettings.collectAsState()
    val admins by mainViewModel.allAdmins.collectAsState()
    val auditLogs by mainViewModel.recentAuditLogs.collectAsState()
    val shifts by mainViewModel.allShifts.collectAsState()

    var companyName by remember { mutableStateOf(settings.companyName) }
    var address by remember { mutableStateOf(settings.address) }
    var email by remember { mutableStateOf(settings.contactEmail) }
    var phone by remember { mutableStateOf(settings.contactPhone) }
    var defaultShift by remember { mutableStateOf(settings.defaultShiftName) }
    var weekOffDay by remember { mutableStateOf(settings.weekOffDay) }

    var showAddAdminDialog by remember { mutableStateOf(false) }
    var showRestoreDialog by remember { mutableStateOf(false) }
    var adminToDelete by remember { mutableStateOf<AppUser?>(null) }
    var shiftMenuExpanded by remember { mutableStateOf(false) }

    LaunchedEffect(settings) {
        companyName = settings.companyName
        address = settings.address
        email = settings.contactEmail
        phone = settings.contactPhone
        defaultShift = settings.defaultShiftName
        weekOffDay = settings.weekOffDay
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Settings & Administration",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )

        // 1. Company Profile Settings Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(16.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Business, contentDescription = null, tint = PrimaryNavy)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Workplace & Company Profile", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                }

                OutlinedTextField(
                    value = companyName,
                    onValueChange = { companyName = it },
                    label = { Text("Company / Workplace Name") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("Address") },
                    modifier = Modifier.fillMaxWidth()
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("Contact Email") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text("Contact Phone") },
                        modifier = Modifier.weight(1f)
                    )
                }

                Box(modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(
                        onClick = { shiftMenuExpanded = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Default Shift: $defaultShift")
                    }
                    DropdownMenu(
                        expanded = shiftMenuExpanded,
                        onDismissRequest = { shiftMenuExpanded = false }
                    ) {
                        shifts.forEach { shift ->
                            DropdownMenuItem(
                                text = { Text(shift.name) },
                                onClick = {
                                    defaultShift = shift.name
                                    shiftMenuExpanded = false
                                }
                            )
                        }
                    }
                }

                Button(
                    onClick = {
                        val updated = settings.copy(
                            companyName = companyName,
                            address = address,
                            contactEmail = email,
                            contactPhone = phone,
                            defaultShiftName = defaultShift,
                            weekOffDay = weekOffDay
                        )
                        mainViewModel.updateCompanySettings(updated)
                    },
                    modifier = Modifier.align(Alignment.End),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Save Settings")
                }
            }
        }

        // 2. Admin Accounts Management (Owner Only)
        if (currentUser.role == UserRole.OWNER) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.SupervisorAccount, contentDescription = null, tint = PrimaryNavy)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Admin Accounts", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                        }

                        Button(
                            onClick = { showAddAdminDialog = true },
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier.testTag("add_admin_button")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Add Admin", fontSize = 12.sp)
                        }
                    }

                    if (admins.isEmpty()) {
                        Text(
                            "No secondary Admins configured. Only you (Owner) have access.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        admins.forEach { admin ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(admin.displayName, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                    Text("ID: ${admin.username}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Switch(
                                        checked = admin.isActive,
                                        onCheckedChange = { mainViewModel.toggleAdminActive(admin) }
                                    )
                                    IconButton(onClick = { adminToDelete = admin }) {
                                        Icon(Icons.Default.DeleteOutline, contentDescription = "Delete Admin", tint = StatusAbsent)
                                    }
                                }
                            }
                            Divider()
                        }
                    }
                }
            }

            // 3. Backup & Restore (Owner Only)
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Backup, contentDescription = null, tint = PrimaryNavy)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Backup & Restore Data", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                    }

                    Text(
                        "Securely export all employees, attendance history, shifts, overtime, and holidays into a portable JSON backup file. No cloud required.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { mainViewModel.createAndShareBackup(context) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("create_backup_button"),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Export Backup", fontSize = 12.sp)
                        }

                        Button(
                            onClick = { showRestoreDialog = true },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("restore_backup_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Restore, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Restore DB", fontSize = 12.sp)
                        }
                    }
                }
            }

            // 4. Audit Trail Logs (Owner Only)
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.History, contentDescription = null, tint = PrimaryNavy)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Security Audit Logs", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                    }

                    if (auditLogs.isEmpty()) {
                        Text("No audit log events recorded yet.", style = MaterialTheme.typography.bodySmall)
                    } else {
                        auditLogs.take(15).forEach { log ->
                            Column(modifier = Modifier.padding(vertical = 4.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "${log.performedBy} (${log.role.name}) - ${log.action}",
                                        fontWeight = FontWeight.SemiBold,
                                        style = MaterialTheme.typography.labelMedium
                                    )
                                    Text(
                                        text = log.timestamp.take(19).replace("T", " "),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Text(
                                    text = log.details,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Divider()
                        }
                    }
                }
            }
        }
    }

    if (showAddAdminDialog) {
        AddAdminDialog(
            onDismiss = { showAddAdminDialog = false },
            onSave = { username, pin, name ->
                mainViewModel.createAdmin(username, pin, name)
            }
        )
    }

    if (showRestoreDialog) {
        RestoreWarningDialog(
            onDismiss = { showRestoreDialog = false },
            onConfirm = { json ->
                mainViewModel.restoreFromJson(json)
            }
        )
    }

    if (adminToDelete != null) {
        AlertDialog(
            onDismissRequest = { adminToDelete = null },
            title = { Text("Delete Admin Account?") },
            text = { Text("Are you sure you want to permanently delete Admin '${adminToDelete?.displayName}' (${adminToDelete?.username})?") },
            confirmButton = {
                Button(
                    onClick = {
                        adminToDelete?.let { mainViewModel.deleteAdmin(it) }
                        adminToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { adminToDelete = null }) { Text("Cancel") }
            }
        )
    }
}
