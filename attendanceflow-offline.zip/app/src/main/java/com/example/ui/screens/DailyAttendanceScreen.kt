package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AttendanceStatus
import com.example.ui.theme.*
import com.example.ui.viewmodel.DailyAttendanceRow
import com.example.ui.viewmodel.MainViewModel
import com.example.util.DateUtils

@Composable
fun DailyAttendanceScreen(
    mainViewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val selectedDate by mainViewModel.selectedAttendanceDate.collectAsState()
    val rows by mainViewModel.dailyAttendanceRows.collectAsState()
    val departments by mainViewModel.distinctDepartments.collectAsState()
    val shifts by mainViewModel.allShifts.collectAsState()

    var selectedDept by remember { mutableStateOf("All") }
    var selectedShift by remember { mutableStateOf("All") }
    var searchQuery by remember { mutableStateOf("") }

    // Filter rows
    val filteredRows = rows.filter { row ->
        val matchesDept = selectedDept == "All" || row.employee.department.equals(selectedDept, ignoreCase = true)
        val matchesShift = selectedShift == "All" || row.employee.defaultShiftName.equals(selectedShift, ignoreCase = true)
        val matchesSearch = searchQuery.isBlank() ||
                row.employee.name.contains(searchQuery, ignoreCase = true) ||
                row.employee.employeeId.contains(searchQuery, ignoreCase = true)
        matchesDept && matchesShift && matchesSearch
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Date Navigation Bar
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(16.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(
                    onClick = {
                        val prev = DateUtils.getPreviousDate(selectedDate)
                        mainViewModel.setSelectedDate(prev)
                    },
                    modifier = Modifier.testTag("prev_date_button")
                ) {
                    Icon(Icons.Default.ChevronLeft, contentDescription = "Previous Day")
                }

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.clickable {
                        // Reset to today on click
                        mainViewModel.setSelectedDate(DateUtils.getTodayDate())
                    }
                ) {
                    Text(
                        text = DateUtils.formatToDisplayDate(selectedDate),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${DateUtils.getDayOfWeek(selectedDate)} ${if (selectedDate == DateUtils.getTodayDate()) "(Today)" else ""}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                IconButton(
                    onClick = {
                        val next = DateUtils.getNextDate(selectedDate)
                        mainViewModel.setSelectedDate(next)
                    },
                    modifier = Modifier.testTag("next_date_button")
                ) {
                    Icon(Icons.Default.ChevronRight, contentDescription = "Next Day")
                }
            }
        }

        // Quick Batch Operations & Save Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedButton(
                onClick = { mainViewModel.markAllPresent() },
                modifier = Modifier
                    .weight(1f)
                    .testTag("mark_all_present_button"),
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
            ) {
                Icon(Icons.Default.DoneAll, contentDescription = null, tint = StatusPresent, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("All Present", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }

            OutlinedButton(
                onClick = { mainViewModel.markAllWeekOff() },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
            ) {
                Icon(Icons.Default.Weekend, contentDescription = null, tint = StatusWeekOff, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("All Week Off", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }

            Button(
                onClick = { mainViewModel.saveAttendance() },
                modifier = Modifier
                    .weight(1.2f)
                    .testTag("save_attendance_button"),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryNavy),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Save", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
        }

        // Search & Filter Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search by name or ID...", fontSize = 13.sp) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Close, contentDescription = "Clear", modifier = Modifier.size(16.dp))
                        }
                    }
                },
                singleLine = true,
                modifier = Modifier
                    .weight(1f)
                    .height(50.dp)
                    .testTag("attendance_search_input"),
                shape = RoundedCornerShape(12.dp)
            )
        }

        // Summary Chips Row (Count of filtered items)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Showing ${filteredRows.size} of ${rows.size} employees",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            val pCount = filteredRows.count { it.status == AttendanceStatus.PRESENT }
            val aCount = filteredRows.count { it.status == AttendanceStatus.ABSENT }
            Text(
                text = "P: $pCount | A: $aCount",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }

        // Employee Attendance Cards List
        if (filteredRows.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Default.PeopleOutline,
                        contentDescription = null,
                        modifier = Modifier.size(48.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (rows.isEmpty()) "No active employees found.\nAdd employees in Employee Management." else "No employees match your filter.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filteredRows, key = { it.employee.employeeId }) { row ->
                    AttendanceRowCard(
                        row = row,
                        onStatusChange = { newStatus ->
                            mainViewModel.updateRowStatus(row.employee.employeeId, newStatus)
                        },
                        onOtChange = { ot ->
                            mainViewModel.updateRowOt(row.employee.employeeId, ot)
                        },
                        onRemarksChange = { rem ->
                            mainViewModel.updateRowRemarks(row.employee.employeeId, rem)
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun AttendanceRowCard(
    row: DailyAttendanceRow,
    onStatusChange: (AttendanceStatus) -> Unit,
    onOtChange: (Double) -> Unit,
    onRemarksChange: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("attendance_card_${row.employee.employeeId}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(14.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Employee Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = row.employee.name.take(1).uppercase(),
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            fontSize = 14.sp
                        )
                    }

                    Column {
                        Text(
                            text = row.employee.name,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${row.employee.employeeId} • ${row.employee.department} • ${row.employee.defaultShiftName}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Current Status Badge
                Surface(
                    color = getStatusBgColor(row.status),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = row.status.displayName,
                        color = getStatusTextColor(row.status),
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.labelMedium,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            // Quick Status Chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                StatusToggleChip(
                    label = "P",
                    title = "Present",
                    isSelected = row.status == AttendanceStatus.PRESENT,
                    activeColor = StatusPresent,
                    activeBgColor = StatusPresentBg,
                    onClick = { onStatusChange(AttendanceStatus.PRESENT) },
                    modifier = Modifier.weight(1f)
                )
                StatusToggleChip(
                    label = "A",
                    title = "Absent",
                    isSelected = row.status == AttendanceStatus.ABSENT,
                    activeColor = StatusAbsent,
                    activeBgColor = StatusAbsentBg,
                    onClick = { onStatusChange(AttendanceStatus.ABSENT) },
                    modifier = Modifier.weight(1f)
                )
                StatusToggleChip(
                    label = "L",
                    title = "Leave",
                    isSelected = row.status == AttendanceStatus.LEAVE,
                    activeColor = StatusLeave,
                    activeBgColor = StatusLeaveBg,
                    onClick = { onStatusChange(AttendanceStatus.LEAVE) },
                    modifier = Modifier.weight(1f)
                )
                StatusToggleChip(
                    label = "HD",
                    title = "Half Day",
                    isSelected = row.status == AttendanceStatus.HALF_DAY,
                    activeColor = StatusHalfDay,
                    activeBgColor = StatusHalfDayBg,
                    onClick = { onStatusChange(AttendanceStatus.HALF_DAY) },
                    modifier = Modifier.weight(1f)
                )
                StatusToggleChip(
                    label = "WO",
                    title = "Week Off",
                    isSelected = row.status == AttendanceStatus.WEEK_OFF,
                    activeColor = StatusWeekOff,
                    activeBgColor = StatusWeekOffBg,
                    onClick = { onStatusChange(AttendanceStatus.WEEK_OFF) },
                    modifier = Modifier.weight(1f)
                )
                StatusToggleChip(
                    label = "H",
                    title = "Holiday",
                    isSelected = row.status == AttendanceStatus.HOLIDAY,
                    activeColor = StatusHoliday,
                    activeBgColor = StatusHolidayBg,
                    onClick = { onStatusChange(AttendanceStatus.HOLIDAY) },
                    modifier = Modifier.weight(1f)
                )
            }

            // Overtime & Remarks row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text("OT (hrs):", style = MaterialTheme.typography.labelSmall)
                    IconButton(
                        onClick = { if (row.otHours >= 0.5) onOtChange(row.otHours - 0.5) },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(Icons.Default.RemoveCircleOutline, contentDescription = "Decrease OT", modifier = Modifier.size(16.dp))
                    }
                    Text(
                        text = if (row.otHours > 0) "%.1f".format(row.otHours) else "0",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (row.otHours > 0) AccentAmber else MaterialTheme.colorScheme.onSurface
                    )
                    IconButton(
                        onClick = { onOtChange(row.otHours + 0.5) },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(Icons.Default.AddCircleOutline, contentDescription = "Increase OT", modifier = Modifier.size(16.dp))
                    }
                }

                TextButton(
                    onClick = { expanded = !expanded },
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)
                ) {
                    Text(
                        text = if (row.remarks.isNotBlank()) "Remark: ${row.remarks.take(12)}.." else "Add Remark",
                        style = MaterialTheme.typography.labelSmall
                    )
                    Icon(
                        imageVector = if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            if (expanded) {
                OutlinedTextField(
                    value = row.remarks,
                    onValueChange = onRemarksChange,
                    label = { Text("Remarks (e.g. Late by 15m / Medical leave)", fontSize = 11.sp) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
fun StatusToggleChip(
    label: String,
    title: String,
    isSelected: Boolean,
    activeColor: Color,
    activeBgColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        modifier = modifier
            .height(34.dp)
            .clip(RoundedCornerShape(8.dp)),
        color = if (isSelected) activeBgColor else MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(8.dp)
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Normal,
                color = if (isSelected) activeColor else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

fun getStatusBgColor(status: AttendanceStatus): Color {
    return when (status) {
        AttendanceStatus.PRESENT -> StatusPresentBg
        AttendanceStatus.ABSENT -> StatusAbsentBg
        AttendanceStatus.LEAVE -> StatusLeaveBg
        AttendanceStatus.HALF_DAY -> StatusHalfDayBg
        AttendanceStatus.WEEK_OFF -> StatusWeekOffBg
        AttendanceStatus.HOLIDAY -> StatusHolidayBg
    }
}

fun getStatusTextColor(status: AttendanceStatus): Color {
    return when (status) {
        AttendanceStatus.PRESENT -> StatusPresent
        AttendanceStatus.ABSENT -> StatusAbsent
        AttendanceStatus.LEAVE -> StatusLeave
        AttendanceStatus.HALF_DAY -> StatusHalfDay
        AttendanceStatus.WEEK_OFF -> StatusWeekOff
        AttendanceStatus.HOLIDAY -> StatusHoliday
    }
}
