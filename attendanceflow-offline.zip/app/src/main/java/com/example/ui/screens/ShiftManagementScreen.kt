package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Shift
import com.example.ui.theme.PrimaryNavy
import com.example.ui.theme.StatusPresent
import com.example.ui.theme.StatusPresentBg
import com.example.ui.viewmodel.MainViewModel

@Composable
fun ShiftManagementScreen(
    mainViewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val shifts by mainViewModel.allShifts.collectAsState()
    var showAddDialog by remember { mutableStateOf(false) }
    var shiftToEdit by remember { mutableStateOf<Shift?>(null) }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = PrimaryNavy,
                contentColor = Color.White,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.testTag("add_shift_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Shift")
            }
        }
    ) { paddingValues ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = "Shift Configuration",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Configure work shifts, standard operating hours, and break periods.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(shifts, key = { it.id }) { shift ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("shift_card_${shift.id}"),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(16.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        Icons.Default.Schedule,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = shift.name,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                Text(
                                    text = "Hours: ${shift.startTime} – ${shift.endTime}  (${shift.breakMinutes}m break)",
                                    style = MaterialTheme.typography.bodyMedium
                                )

                                if (shift.description.isNotBlank()) {
                                    Text(
                                        text = shift.description,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            IconButton(onClick = { shiftToEdit = shift }) {
                                Icon(Icons.Default.Edit, contentDescription = "Edit Shift")
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AddEditShiftDialog(
            shift = null,
            onDismiss = { showAddDialog = false },
            onSave = { name, start, end, breakMin, desc ->
                mainViewModel.addShift(name, start, end, breakMin, desc)
            }
        )
    }

    if (shiftToEdit != null) {
        AddEditShiftDialog(
            shift = shiftToEdit,
            onDismiss = { shiftToEdit = null },
            onSave = { name, start, end, breakMin, desc ->
                mainViewModel.updateShift(
                    shiftToEdit!!.copy(
                        name = name,
                        startTime = start,
                        endTime = end,
                        breakMinutes = breakMin,
                        description = desc
                    )
                )
                shiftToEdit = null
            }
        )
    }
}
